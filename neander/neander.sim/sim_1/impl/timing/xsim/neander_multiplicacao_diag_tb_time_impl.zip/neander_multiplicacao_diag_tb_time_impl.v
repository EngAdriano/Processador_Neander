// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
// Date        : Mon Nov  2 08:35:33 2026
// Host        : INVENCTUS_ENG running 64-bit major release  (build 9200)
// Command     : write_verilog -mode timesim -nolib -sdf_anno true -force -file
//               D:/Repositorio_Git/Processador_Neander/neander/neander.sim/sim_1/impl/timing/xsim/neander_multiplicacao_diag_tb_time_impl.v
// Design      : neander
// Purpose     : This verilog netlist is a timing simulation representation of the design and should not be modified or
//               synthesized. Please ensure that this netlist is used with the corresponding SDF file.
// Device      : xc7a100tcsg324-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps
`define XIL_TIMING

module acumulador
   (dina,
    resultado_ula_OBUF,
    \q_reg[4]_0 ,
    \q_reg[5]_0 ,
    \q_reg[6]_0 ,
    S,
    \q_reg[7]_0 ,
    \q_reg[3]_0 ,
    \q_reg[3]_1 ,
    reset_IBUF,
    E,
    clk_IBUF_BUFG,
    O,
    \q_reg[4]_1 ,
    D,
    \q_reg[4]_2 ,
    \q_reg[7]_1 ,
    Q,
    \q_reg[7]_2 ,
    \q_reg[6]_1 );
  output [7:0]dina;
  output [0:0]resultado_ula_OBUF;
  output \q_reg[4]_0 ;
  output \q_reg[5]_0 ;
  output \q_reg[6]_0 ;
  output [3:0]S;
  output [3:0]\q_reg[7]_0 ;
  output [3:0]\q_reg[3]_0 ;
  output [3:0]\q_reg[3]_1 ;
  input reset_IBUF;
  input [0:0]E;
  input clk_IBUF_BUFG;
  input [3:0]O;
  input \q_reg[4]_1 ;
  input [7:0]D;
  input \q_reg[4]_2 ;
  input [3:0]\q_reg[7]_1 ;
  input [0:0]Q;
  input \q_reg[7]_2 ;
  input [6:0]\q_reg[6]_1 ;

  wire [7:0]D;
  wire [0:0]E;
  wire [3:0]O;
  wire [0:0]Q;
  wire [3:0]S;
  wire clk_IBUF_BUFG;
  wire [7:0]dina;
  wire [3:0]\q_reg[3]_0 ;
  wire [3:0]\q_reg[3]_1 ;
  wire \q_reg[4]_0 ;
  wire \q_reg[4]_1 ;
  wire \q_reg[4]_2 ;
  wire \q_reg[5]_0 ;
  wire \q_reg[6]_0 ;
  wire [6:0]\q_reg[6]_1 ;
  wire [3:0]\q_reg[7]_0 ;
  wire [3:0]\q_reg[7]_1 ;
  wire \q_reg[7]_2 ;
  wire reset_IBUF;
  wire [0:0]resultado_ula_OBUF;
  wire \resultado_ula_OBUF[7]_inst_i_3_n_0 ;

  LUT2 #(
    .INIT(4'h9)) 
    i__carry__0_i_1
       (.I0(dina[7]),
        .I1(D[7]),
        .O(S[3]));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry__0_i_2
       (.I0(D[6]),
        .I1(dina[6]),
        .O(S[2]));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry__0_i_3
       (.I0(D[5]),
        .I1(dina[5]),
        .O(S[1]));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry__0_i_4
       (.I0(D[4]),
        .I1(dina[4]),
        .O(S[0]));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_1
       (.I0(D[3]),
        .I1(dina[3]),
        .O(\q_reg[3]_1 [3]));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_2
       (.I0(D[2]),
        .I1(dina[2]),
        .O(\q_reg[3]_1 [2]));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_3
       (.I0(D[1]),
        .I1(dina[1]),
        .O(\q_reg[3]_1 [1]));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_4
       (.I0(D[0]),
        .I1(dina[0]),
        .O(\q_reg[3]_1 [0]));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(\q_reg[6]_1 [0]),
        .Q(dina[0]),
        .R(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(\q_reg[6]_1 [1]),
        .Q(dina[1]),
        .R(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(\q_reg[6]_1 [2]),
        .Q(dina[2]),
        .R(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(\q_reg[6]_1 [3]),
        .Q(dina[3]),
        .R(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[4] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(\q_reg[6]_1 [4]),
        .Q(dina[4]),
        .R(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[5] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(\q_reg[6]_1 [5]),
        .Q(dina[5]),
        .R(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[6] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(\q_reg[6]_1 [6]),
        .Q(dina[6]),
        .R(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[7] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(resultado_ula_OBUF),
        .Q(dina[7]),
        .R(reset_IBUF));
  LUT2 #(
    .INIT(4'h6)) 
    resultado0_carry__0_i_1
       (.I0(D[7]),
        .I1(dina[7]),
        .O(\q_reg[7]_0 [3]));
  LUT2 #(
    .INIT(4'h6)) 
    resultado0_carry__0_i_2
       (.I0(dina[6]),
        .I1(D[6]),
        .O(\q_reg[7]_0 [2]));
  LUT2 #(
    .INIT(4'h6)) 
    resultado0_carry__0_i_3
       (.I0(dina[5]),
        .I1(D[5]),
        .O(\q_reg[7]_0 [1]));
  LUT2 #(
    .INIT(4'h6)) 
    resultado0_carry__0_i_4
       (.I0(dina[4]),
        .I1(D[4]),
        .O(\q_reg[7]_0 [0]));
  LUT2 #(
    .INIT(4'h6)) 
    resultado0_carry_i_1
       (.I0(dina[3]),
        .I1(D[3]),
        .O(\q_reg[3]_0 [3]));
  LUT2 #(
    .INIT(4'h6)) 
    resultado0_carry_i_2
       (.I0(dina[2]),
        .I1(D[2]),
        .O(\q_reg[3]_0 [2]));
  LUT2 #(
    .INIT(4'h6)) 
    resultado0_carry_i_3
       (.I0(dina[1]),
        .I1(D[1]),
        .O(\q_reg[3]_0 [1]));
  LUT2 #(
    .INIT(4'h6)) 
    resultado0_carry_i_4
       (.I0(dina[0]),
        .I1(D[0]),
        .O(\q_reg[3]_0 [0]));
  LUT6 #(
    .INIT(64'hAFA0CF0FAFA0C000)) 
    \resultado_ula_OBUF[4]_inst_i_2 
       (.I0(O[0]),
        .I1(dina[4]),
        .I2(\q_reg[4]_1 ),
        .I3(D[4]),
        .I4(\q_reg[4]_2 ),
        .I5(\q_reg[7]_1 [0]),
        .O(\q_reg[4]_0 ));
  LUT6 #(
    .INIT(64'hAFA0CF0FAFA0C000)) 
    \resultado_ula_OBUF[5]_inst_i_2 
       (.I0(O[1]),
        .I1(dina[5]),
        .I2(\q_reg[4]_1 ),
        .I3(D[5]),
        .I4(\q_reg[4]_2 ),
        .I5(\q_reg[7]_1 [1]),
        .O(\q_reg[5]_0 ));
  LUT6 #(
    .INIT(64'h505F30F0505F3FFF)) 
    \resultado_ula_OBUF[6]_inst_i_3 
       (.I0(O[2]),
        .I1(dina[6]),
        .I2(\q_reg[4]_1 ),
        .I3(D[6]),
        .I4(\q_reg[4]_2 ),
        .I5(\q_reg[7]_1 [2]),
        .O(\q_reg[6]_0 ));
  LUT5 #(
    .INIT(32'h3EFF3E00)) 
    \resultado_ula_OBUF[7]_inst_i_1 
       (.I0(D[7]),
        .I1(dina[7]),
        .I2(Q),
        .I3(\q_reg[7]_2 ),
        .I4(\resultado_ula_OBUF[7]_inst_i_3_n_0 ),
        .O(resultado_ula_OBUF));
  LUT6 #(
    .INIT(64'hAFA0CF0FAFA0C000)) 
    \resultado_ula_OBUF[7]_inst_i_3 
       (.I0(O[3]),
        .I1(dina[7]),
        .I2(\q_reg[4]_1 ),
        .I3(D[7]),
        .I4(\q_reg[4]_2 ),
        .I5(\q_reg[7]_1 [3]),
        .O(\resultado_ula_OBUF[7]_inst_i_3_n_0 ));
endmodule

module caminho_dados
   (douta,
    addra,
    n_OBUF,
    Q,
    z_OBUF,
    resultado_ula_OBUF,
    D,
    \ri_reg[7] ,
    \ri_reg[6] ,
    \rem_reg[7] ,
    z_reg,
    \pc_reg[7] ,
    \FSM_onehot_estado_reg[6] ,
    \ri_reg[4] ,
    clk_IBUF_BUFG,
    ena,
    wea,
    reset_IBUF,
    \pc[7]_i_3 ,
    E,
    lopt);
  output [7:0]douta;
  output [7:0]addra;
  output n_OBUF;
  output [6:0]Q;
  output z_OBUF;
  output [7:0]resultado_ula_OBUF;
  output [5:0]D;
  output [7:0]\ri_reg[7] ;
  output \ri_reg[6] ;
  output [7:0]\rem_reg[7] ;
  output z_reg;
  output [7:0]\pc_reg[7] ;
  output \FSM_onehot_estado_reg[6] ;
  output \ri_reg[4] ;
  input clk_IBUF_BUFG;
  input ena;
  input [0:0]wea;
  input reset_IBUF;
  input [8:0]\pc[7]_i_3 ;
  input [0:0]E;
  output lopt;

  wire [5:0]D;
  wire [0:0]E;
  wire \FSM_onehot_estado_reg[6] ;
  wire [6:0]Q;
  wire [7:0]addra;
  wire clk_IBUF_BUFG;
  wire [7:4]data1;
  wire [7:4]data2;
  wire [7:0]douta;
  wire ena;
  wire lopt;
  wire n_OBUF;
  wire [0:0]p_0_in;
  wire [8:0]\pc[7]_i_3 ;
  wire [7:0]\pc_reg[7] ;
  wire [7:0]\rem_reg[7] ;
  wire reset_IBUF;
  wire [7:0]resultado_ula_OBUF;
  wire \ri_reg[4] ;
  wire \ri_reg[6] ;
  wire [7:0]\ri_reg[7] ;
  wire u_ac_n_10;
  wire u_ac_n_11;
  wire u_ac_n_12;
  wire u_ac_n_13;
  wire u_ac_n_14;
  wire u_ac_n_15;
  wire u_ac_n_16;
  wire u_ac_n_17;
  wire u_ac_n_18;
  wire u_ac_n_19;
  wire u_ac_n_20;
  wire u_ac_n_21;
  wire u_ac_n_22;
  wire u_ac_n_23;
  wire u_ac_n_24;
  wire u_ac_n_25;
  wire u_ac_n_26;
  wire u_ac_n_27;
  wire u_ac_n_9;
  wire u_ri_n_23;
  wire u_ri_n_24;
  wire u_ri_n_27;
  wire u_ri_n_29;
  wire u_ula_n_10;
  wire u_ula_n_11;
  wire u_ula_n_8;
  wire u_ula_n_9;
  wire [0:0]wea;
  wire z_OBUF;
  wire z_in;
  wire z_reg;

  acumulador u_ac
       (.D(douta),
        .E(u_ri_n_29),
        .O(data2),
        .Q(\ri_reg[7] [5]),
        .S({u_ac_n_12,u_ac_n_13,u_ac_n_14,u_ac_n_15}),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .dina({n_OBUF,Q}),
        .\q_reg[3]_0 ({u_ac_n_20,u_ac_n_21,u_ac_n_22,u_ac_n_23}),
        .\q_reg[3]_1 ({u_ac_n_24,u_ac_n_25,u_ac_n_26,u_ac_n_27}),
        .\q_reg[4]_0 (u_ac_n_9),
        .\q_reg[4]_1 (u_ri_n_27),
        .\q_reg[4]_2 (u_ri_n_24),
        .\q_reg[5]_0 (u_ac_n_10),
        .\q_reg[6]_0 (u_ac_n_11),
        .\q_reg[6]_1 (resultado_ula_OBUF[6:0]),
        .\q_reg[7]_0 ({u_ac_n_16,u_ac_n_17,u_ac_n_18,u_ac_n_19}),
        .\q_reg[7]_1 (data1),
        .\q_reg[7]_2 (u_ri_n_23),
        .reset_IBUF(reset_IBUF),
        .resultado_ula_OBUF(resultado_ula_OBUF[7]));
  registrador_flags u_flags
       (.E(u_ri_n_29),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .lopt(lopt),
        .reset_IBUF(reset_IBUF),
        .z_OBUF(z_OBUF),
        .z_in(z_in));
  (* CHECK_LICENSE_TYPE = "memoria_neander,blk_mem_gen_v8_4_9,{}" *) 
  (* IMPORTED_FROM = "d:/Repositorio_Git/Processador_Neander/neander/neander.gen/sources_1/ip/memoria_neander/memoria_neander.dcp" *) 
  (* IMPORTED_TYPE = "CHECKPOINT" *) 
  (* IS_IMPORTED *) 
  (* downgradeipidentifiedwarnings = "yes" *) 
  (* x_core_info = "blk_mem_gen_v8_4_9,Vivado 2024.2" *) 
  memoria_neander u_memoria
       (.addra(addra),
        .clka(clk_IBUF_BUFG),
        .dina({n_OBUF,Q}),
        .douta(douta),
        .ena(ena),
        .wea(wea));
  contador_programa u_pc
       (.D(p_0_in),
        .E(E),
        .Q(\pc_reg[7] ),
        .addra(addra),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\pc_reg[7]_0 (\rem_reg[7] ),
        .\pc_reg[7]_1 (z_reg),
        .reset_IBUF(reset_IBUF),
        .\ri_reg[7] ({\pc[7]_i_3 [7],\pc[7]_i_3 [5]}));
  registrador_endereco u_rem
       (.D(p_0_in),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\pc_reg[0] (z_reg),
        .\pc_reg[0]_0 (\pc_reg[7] [0]),
        .\rem_reg[0]_0 (\pc[7]_i_3 [4]),
        .\rem_reg[7]_0 (\rem_reg[7] ),
        .\rem_reg[7]_1 (douta),
        .reset_IBUF(reset_IBUF));
  registrador_instrucao u_ri
       (.D(D),
        .E(u_ri_n_29),
        .\FSM_onehot_estado_reg[6] (\FSM_onehot_estado_reg[6] ),
        .Q(\ri_reg[7] ),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .dina({n_OBUF,Q}),
        .\pc[7]_i_3_0 ({\pc[7]_i_3 [8],\pc[7]_i_3 [6],\pc[7]_i_3 [4:0]}),
        .\q_reg[0] (u_ula_n_8),
        .\q_reg[1] (u_ula_n_9),
        .\q_reg[2] (u_ula_n_10),
        .\q_reg[3] (u_ula_n_11),
        .\q_reg[4] (u_ac_n_9),
        .\q_reg[5] (u_ac_n_10),
        .reset_IBUF(reset_IBUF),
        .resultado_ula_OBUF(resultado_ula_OBUF[6:0]),
        .\ri_reg[4]_0 (\ri_reg[4] ),
        .\ri_reg[6]_0 (\ri_reg[6] ),
        .\ri_reg[6]_1 (u_ri_n_23),
        .\ri_reg[6]_2 (u_ri_n_27),
        .\ri_reg[7]_0 (u_ri_n_24),
        .\ri_reg[7]_1 (douta),
        .z_OBUF(z_OBUF),
        .z_in(z_in),
        .z_reg(z_reg),
        .z_reg_0(resultado_ula_OBUF[7]),
        .z_reg_1(u_ac_n_11));
  ula u_ula
       (.O(data2),
        .S({u_ac_n_12,u_ac_n_13,u_ac_n_14,u_ac_n_15}),
        .dina(Q),
        .douta(douta[3:0]),
        .\q_reg[0] (u_ula_n_8),
        .\q_reg[0]_0 (u_ri_n_27),
        .\q_reg[0]_1 (u_ri_n_24),
        .\q_reg[1] (u_ula_n_9),
        .\q_reg[2] (u_ula_n_10),
        .\q_reg[3] (u_ula_n_11),
        .\q_reg[6] (data1),
        .\resultado_ula_OBUF[0]_inst_i_2_0 ({u_ac_n_20,u_ac_n_21,u_ac_n_22,u_ac_n_23}),
        .\resultado_ula_OBUF[0]_inst_i_2_1 ({u_ac_n_24,u_ac_n_25,u_ac_n_26,u_ac_n_27}),
        .\resultado_ula_OBUF[4]_inst_i_2 ({u_ac_n_16,u_ac_n_17,u_ac_n_18,u_ac_n_19}));
endmodule

module contador_programa
   (Q,
    addra,
    D,
    \pc_reg[7]_0 ,
    \pc_reg[7]_1 ,
    reset_IBUF,
    \ri_reg[7] ,
    E,
    clk_IBUF_BUFG);
  output [7:0]Q;
  output [7:0]addra;
  input [0:0]D;
  input [7:0]\pc_reg[7]_0 ;
  input \pc_reg[7]_1 ;
  input reset_IBUF;
  input [1:0]\ri_reg[7] ;
  input [0:0]E;
  input clk_IBUF_BUFG;

  wire [0:0]D;
  wire [0:0]E;
  wire [7:0]Q;
  wire [7:0]addra;
  wire clk_IBUF_BUFG;
  wire [7:1]p_0_in;
  wire \pc[4]_i_2_n_0 ;
  wire \pc[5]_i_2_n_0 ;
  wire \pc[7]_i_4_n_0 ;
  wire [7:0]\pc_reg[7]_0 ;
  wire \pc_reg[7]_1 ;
  wire reset_IBUF;
  wire [1:0]\ri_reg[7] ;

  LUT5 #(
    .INIT(32'hBBBA888A)) 
    \endereco_memoria_OBUF[0]_inst_i_1 
       (.I0(Q[0]),
        .I1(reset_IBUF),
        .I2(\ri_reg[7] [0]),
        .I3(\ri_reg[7] [1]),
        .I4(\pc_reg[7]_0 [0]),
        .O(addra[0]));
  LUT5 #(
    .INIT(32'hBBBA888A)) 
    \endereco_memoria_OBUF[1]_inst_i_1 
       (.I0(Q[1]),
        .I1(reset_IBUF),
        .I2(\ri_reg[7] [0]),
        .I3(\ri_reg[7] [1]),
        .I4(\pc_reg[7]_0 [1]),
        .O(addra[1]));
  LUT5 #(
    .INIT(32'hBBBA888A)) 
    \endereco_memoria_OBUF[2]_inst_i_1 
       (.I0(Q[2]),
        .I1(reset_IBUF),
        .I2(\ri_reg[7] [0]),
        .I3(\ri_reg[7] [1]),
        .I4(\pc_reg[7]_0 [2]),
        .O(addra[2]));
  LUT5 #(
    .INIT(32'hBBBA888A)) 
    \endereco_memoria_OBUF[3]_inst_i_1 
       (.I0(Q[3]),
        .I1(reset_IBUF),
        .I2(\ri_reg[7] [0]),
        .I3(\ri_reg[7] [1]),
        .I4(\pc_reg[7]_0 [3]),
        .O(addra[3]));
  LUT5 #(
    .INIT(32'hBBBA888A)) 
    \endereco_memoria_OBUF[4]_inst_i_1 
       (.I0(Q[4]),
        .I1(reset_IBUF),
        .I2(\ri_reg[7] [0]),
        .I3(\ri_reg[7] [1]),
        .I4(\pc_reg[7]_0 [4]),
        .O(addra[4]));
  LUT5 #(
    .INIT(32'hBBBA888A)) 
    \endereco_memoria_OBUF[5]_inst_i_1 
       (.I0(Q[5]),
        .I1(reset_IBUF),
        .I2(\ri_reg[7] [0]),
        .I3(\ri_reg[7] [1]),
        .I4(\pc_reg[7]_0 [5]),
        .O(addra[5]));
  LUT5 #(
    .INIT(32'hBBBA888A)) 
    \endereco_memoria_OBUF[6]_inst_i_1 
       (.I0(Q[6]),
        .I1(reset_IBUF),
        .I2(\ri_reg[7] [0]),
        .I3(\ri_reg[7] [1]),
        .I4(\pc_reg[7]_0 [6]),
        .O(addra[6]));
  LUT5 #(
    .INIT(32'hBBBA888A)) 
    \endereco_memoria_OBUF[7]_inst_i_1 
       (.I0(Q[7]),
        .I1(reset_IBUF),
        .I2(\ri_reg[7] [0]),
        .I3(\ri_reg[7] [1]),
        .I4(\pc_reg[7]_0 [7]),
        .O(addra[7]));
  LUT4 #(
    .INIT(16'h8BB8)) 
    \pc[1]_i_1 
       (.I0(\pc_reg[7]_0 [1]),
        .I1(\pc_reg[7]_1 ),
        .I2(Q[0]),
        .I3(Q[1]),
        .O(p_0_in[1]));
  LUT5 #(
    .INIT(32'h8BB8B8B8)) 
    \pc[2]_i_1 
       (.I0(\pc_reg[7]_0 [2]),
        .I1(\pc_reg[7]_1 ),
        .I2(Q[2]),
        .I3(Q[0]),
        .I4(Q[1]),
        .O(p_0_in[2]));
  LUT6 #(
    .INIT(64'h8BB8B8B8B8B8B8B8)) 
    \pc[3]_i_1 
       (.I0(\pc_reg[7]_0 [3]),
        .I1(\pc_reg[7]_1 ),
        .I2(Q[3]),
        .I3(Q[1]),
        .I4(Q[0]),
        .I5(Q[2]),
        .O(p_0_in[3]));
  LUT4 #(
    .INIT(16'hB88B)) 
    \pc[4]_i_1 
       (.I0(\pc_reg[7]_0 [4]),
        .I1(\pc_reg[7]_1 ),
        .I2(Q[4]),
        .I3(\pc[4]_i_2_n_0 ),
        .O(p_0_in[4]));
  LUT4 #(
    .INIT(16'h7FFF)) 
    \pc[4]_i_2 
       (.I0(Q[2]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[3]),
        .O(\pc[4]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'hB88B)) 
    \pc[5]_i_1 
       (.I0(\pc_reg[7]_0 [5]),
        .I1(\pc_reg[7]_1 ),
        .I2(\pc[5]_i_2_n_0 ),
        .I3(Q[5]),
        .O(p_0_in[5]));
  LUT5 #(
    .INIT(32'h7FFFFFFF)) 
    \pc[5]_i_2 
       (.I0(Q[3]),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(Q[2]),
        .I4(Q[4]),
        .O(\pc[5]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'h8BB8)) 
    \pc[6]_i_1 
       (.I0(\pc_reg[7]_0 [6]),
        .I1(\pc_reg[7]_1 ),
        .I2(Q[6]),
        .I3(\pc[7]_i_4_n_0 ),
        .O(p_0_in[6]));
  LUT5 #(
    .INIT(32'h8BB8B8B8)) 
    \pc[7]_i_2 
       (.I0(\pc_reg[7]_0 [7]),
        .I1(\pc_reg[7]_1 ),
        .I2(Q[7]),
        .I3(\pc[7]_i_4_n_0 ),
        .I4(Q[6]),
        .O(p_0_in[7]));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \pc[7]_i_4 
       (.I0(Q[5]),
        .I1(Q[4]),
        .I2(Q[2]),
        .I3(Q[0]),
        .I4(Q[1]),
        .I5(Q[3]),
        .O(\pc[7]_i_4_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \pc_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(D),
        .Q(Q[0]),
        .R(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \pc_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(p_0_in[1]),
        .Q(Q[1]),
        .R(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \pc_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(p_0_in[2]),
        .Q(Q[2]),
        .R(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \pc_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(p_0_in[3]),
        .Q(Q[3]),
        .R(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \pc_reg[4] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(p_0_in[4]),
        .Q(Q[4]),
        .R(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \pc_reg[5] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(p_0_in[5]),
        .Q(Q[5]),
        .R(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \pc_reg[6] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(p_0_in[6]),
        .Q(Q[6]),
        .R(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \pc_reg[7] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(p_0_in[7]),
        .Q(Q[7]),
        .R(reset_IBUF));
endmodule

(* CHECK_LICENSE_TYPE = "memoria_neander,blk_mem_gen_v8_4_9,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "blk_mem_gen_v8_4_9,Vivado 2024.2" *) 
module memoria_neander
   (clka,
    ena,
    wea,
    addra,
    dina,
    douta);
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA CLK" *) (* x_interface_mode = "slave BRAM_PORTA" *) (* x_interface_parameter = "XIL_INTERFACENAME BRAM_PORTA, MEM_ADDRESS_MODE BYTE_ADDRESS, MEM_SIZE 8192, MEM_WIDTH 32, MEM_ECC NONE, MASTER_TYPE OTHER, READ_LATENCY 1" *) input clka;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA EN" *) input ena;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA WE" *) input [0:0]wea;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA ADDR" *) input [7:0]addra;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA DIN" *) input [7:0]dina;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA DOUT" *) output [7:0]douta;

  wire [7:0]addra;
  wire clka;
  wire [7:0]dina;
  wire [7:0]douta;
  wire ena;
  wire [0:0]wea;
  wire NLW_U0_clkb_UNCONNECTED;
  wire NLW_U0_dbiterr_UNCONNECTED;
  wire NLW_U0_deepsleep_UNCONNECTED;
  wire NLW_U0_eccpipece_UNCONNECTED;
  wire NLW_U0_enb_UNCONNECTED;
  wire NLW_U0_injectdbiterr_UNCONNECTED;
  wire NLW_U0_injectsbiterr_UNCONNECTED;
  wire NLW_U0_regcea_UNCONNECTED;
  wire NLW_U0_regceb_UNCONNECTED;
  wire NLW_U0_rsta_UNCONNECTED;
  wire NLW_U0_rsta_busy_UNCONNECTED;
  wire NLW_U0_rstb_UNCONNECTED;
  wire NLW_U0_rstb_busy_UNCONNECTED;
  wire NLW_U0_s_aclk_UNCONNECTED;
  wire NLW_U0_s_aresetn_UNCONNECTED;
  wire NLW_U0_s_axi_arready_UNCONNECTED;
  wire NLW_U0_s_axi_arvalid_UNCONNECTED;
  wire NLW_U0_s_axi_awready_UNCONNECTED;
  wire NLW_U0_s_axi_awvalid_UNCONNECTED;
  wire NLW_U0_s_axi_bready_UNCONNECTED;
  wire NLW_U0_s_axi_bvalid_UNCONNECTED;
  wire NLW_U0_s_axi_dbiterr_UNCONNECTED;
  wire NLW_U0_s_axi_injectdbiterr_UNCONNECTED;
  wire NLW_U0_s_axi_injectsbiterr_UNCONNECTED;
  wire NLW_U0_s_axi_rlast_UNCONNECTED;
  wire NLW_U0_s_axi_rready_UNCONNECTED;
  wire NLW_U0_s_axi_rvalid_UNCONNECTED;
  wire NLW_U0_s_axi_sbiterr_UNCONNECTED;
  wire NLW_U0_s_axi_wlast_UNCONNECTED;
  wire NLW_U0_s_axi_wready_UNCONNECTED;
  wire NLW_U0_s_axi_wvalid_UNCONNECTED;
  wire NLW_U0_sbiterr_UNCONNECTED;
  wire NLW_U0_shutdown_UNCONNECTED;
  wire NLW_U0_sleep_UNCONNECTED;
  wire [7:0]NLW_U0_addrb_UNCONNECTED;
  wire [7:0]NLW_U0_dinb_UNCONNECTED;
  wire [7:0]NLW_U0_doutb_UNCONNECTED;
  wire [7:0]NLW_U0_rdaddrecc_UNCONNECTED;
  wire [31:0]NLW_U0_s_axi_araddr_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_arburst_UNCONNECTED;
  wire [3:0]NLW_U0_s_axi_arid_UNCONNECTED;
  wire [7:0]NLW_U0_s_axi_arlen_UNCONNECTED;
  wire [2:0]NLW_U0_s_axi_arsize_UNCONNECTED;
  wire [31:0]NLW_U0_s_axi_awaddr_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_awburst_UNCONNECTED;
  wire [3:0]NLW_U0_s_axi_awid_UNCONNECTED;
  wire [7:0]NLW_U0_s_axi_awlen_UNCONNECTED;
  wire [2:0]NLW_U0_s_axi_awsize_UNCONNECTED;
  wire [3:0]NLW_U0_s_axi_bid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_bresp_UNCONNECTED;
  wire [7:0]NLW_U0_s_axi_rdaddrecc_UNCONNECTED;
  wire [7:0]NLW_U0_s_axi_rdata_UNCONNECTED;
  wire [3:0]NLW_U0_s_axi_rid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_rresp_UNCONNECTED;
  wire [7:0]NLW_U0_s_axi_wdata_UNCONNECTED;
  wire [0:0]NLW_U0_s_axi_wstrb_UNCONNECTED;
  wire [0:0]NLW_U0_web_UNCONNECTED;

  (* C_ADDRA_WIDTH = "8" *) 
  (* C_ADDRB_WIDTH = "8" *) 
  (* C_ALGORITHM = "1" *) 
  (* C_AXI_ID_WIDTH = "4" *) 
  (* C_AXI_SLAVE_TYPE = "0" *) 
  (* C_AXI_TYPE = "1" *) 
  (* C_BYTE_SIZE = "9" *) 
  (* C_COMMON_CLK = "0" *) 
  (* C_COUNT_18K_BRAM = "1" *) 
  (* C_COUNT_36K_BRAM = "0" *) 
  (* C_CTRL_ECC_ALGO = "NONE" *) 
  (* C_DEFAULT_DATA = "0" *) 
  (* C_DISABLE_WARN_BHV_COLL = "0" *) 
  (* C_DISABLE_WARN_BHV_RANGE = "0" *) 
  (* C_ELABORATION_DIR = "./" *) 
  (* C_ENABLE_32BIT_ADDRESS = "0" *) 
  (* C_EN_DEEPSLEEP_PIN = "0" *) 
  (* C_EN_ECC_PIPE = "0" *) 
  (* C_EN_RDADDRA_CHG = "0" *) 
  (* C_EN_RDADDRB_CHG = "0" *) 
  (* C_EN_SAFETY_CKT = "0" *) 
  (* C_EN_SHUTDOWN_PIN = "0" *) 
  (* C_EN_SLEEP_PIN = "0" *) 
  (* C_EST_POWER_SUMMARY = "Estimated Power for IP     :     2.54005 mW" *) 
  (* C_FAMILY = "artix7" *) 
  (* C_HAS_AXI_ID = "0" *) 
  (* C_HAS_ENA = "1" *) 
  (* C_HAS_ENB = "0" *) 
  (* C_HAS_INJECTERR = "0" *) 
  (* C_HAS_MEM_OUTPUT_REGS_A = "0" *) 
  (* C_HAS_MEM_OUTPUT_REGS_B = "0" *) 
  (* C_HAS_MUX_OUTPUT_REGS_A = "0" *) 
  (* C_HAS_MUX_OUTPUT_REGS_B = "0" *) 
  (* C_HAS_REGCEA = "0" *) 
  (* C_HAS_REGCEB = "0" *) 
  (* C_HAS_RSTA = "0" *) 
  (* C_HAS_RSTB = "0" *) 
  (* C_HAS_SOFTECC_INPUT_REGS_A = "0" *) 
  (* C_HAS_SOFTECC_OUTPUT_REGS_B = "0" *) 
  (* C_INITA_VAL = "0" *) 
  (* C_INITB_VAL = "0" *) 
  (* C_INIT_FILE = "memoria_neander.mem" *) 
  (* C_INIT_FILE_NAME = "memoria_neander.mif" *) 
  (* C_INTERFACE_TYPE = "0" *) 
  (* C_LOAD_INIT_FILE = "1" *) 
  (* C_MEM_TYPE = "0" *) 
  (* C_MUX_PIPELINE_STAGES = "0" *) 
  (* C_PRIM_TYPE = "1" *) 
  (* C_READ_DEPTH_A = "256" *) 
  (* C_READ_DEPTH_B = "256" *) 
  (* C_READ_LATENCY_A = "1" *) 
  (* C_READ_LATENCY_B = "1" *) 
  (* C_READ_WIDTH_A = "8" *) 
  (* C_READ_WIDTH_B = "8" *) 
  (* C_RSTRAM_A = "0" *) 
  (* C_RSTRAM_B = "0" *) 
  (* C_RST_PRIORITY_A = "CE" *) 
  (* C_RST_PRIORITY_B = "CE" *) 
  (* C_SIM_COLLISION_CHECK = "ALL" *) 
  (* C_USE_BRAM_BLOCK = "0" *) 
  (* C_USE_BYTE_WEA = "0" *) 
  (* C_USE_BYTE_WEB = "0" *) 
  (* C_USE_DEFAULT_DATA = "1" *) 
  (* C_USE_ECC = "0" *) 
  (* C_USE_SOFTECC = "0" *) 
  (* C_USE_URAM = "0" *) 
  (* C_WEA_WIDTH = "1" *) 
  (* C_WEB_WIDTH = "1" *) 
  (* C_WRITE_DEPTH_A = "256" *) 
  (* C_WRITE_DEPTH_B = "256" *) 
  (* C_WRITE_MODE_A = "WRITE_FIRST" *) 
  (* C_WRITE_MODE_B = "WRITE_FIRST" *) 
  (* C_WRITE_WIDTH_A = "8" *) 
  (* C_WRITE_WIDTH_B = "8" *) 
  (* C_XDEVICEFAMILY = "artix7" *) 
  (* downgradeipidentifiedwarnings = "yes" *) 
  (* is_du_within_envelope = "true" *) 
  memoria_neander_blk_mem_gen_v8_4_9 U0
       (.addra(addra),
        .addrb(NLW_U0_addrb_UNCONNECTED[7:0]),
        .clka(clka),
        .clkb(NLW_U0_clkb_UNCONNECTED),
        .dbiterr(NLW_U0_dbiterr_UNCONNECTED),
        .deepsleep(NLW_U0_deepsleep_UNCONNECTED),
        .dina(dina),
        .dinb(NLW_U0_dinb_UNCONNECTED[7:0]),
        .douta(douta),
        .doutb(NLW_U0_doutb_UNCONNECTED[7:0]),
        .eccpipece(NLW_U0_eccpipece_UNCONNECTED),
        .ena(ena),
        .enb(NLW_U0_enb_UNCONNECTED),
        .injectdbiterr(NLW_U0_injectdbiterr_UNCONNECTED),
        .injectsbiterr(NLW_U0_injectsbiterr_UNCONNECTED),
        .rdaddrecc(NLW_U0_rdaddrecc_UNCONNECTED[7:0]),
        .regcea(NLW_U0_regcea_UNCONNECTED),
        .regceb(NLW_U0_regceb_UNCONNECTED),
        .rsta(NLW_U0_rsta_UNCONNECTED),
        .rsta_busy(NLW_U0_rsta_busy_UNCONNECTED),
        .rstb(NLW_U0_rstb_UNCONNECTED),
        .rstb_busy(NLW_U0_rstb_busy_UNCONNECTED),
        .s_aclk(NLW_U0_s_aclk_UNCONNECTED),
        .s_aresetn(NLW_U0_s_aresetn_UNCONNECTED),
        .s_axi_araddr(NLW_U0_s_axi_araddr_UNCONNECTED[31:0]),
        .s_axi_arburst(NLW_U0_s_axi_arburst_UNCONNECTED[1:0]),
        .s_axi_arid(NLW_U0_s_axi_arid_UNCONNECTED[3:0]),
        .s_axi_arlen(NLW_U0_s_axi_arlen_UNCONNECTED[7:0]),
        .s_axi_arready(NLW_U0_s_axi_arready_UNCONNECTED),
        .s_axi_arsize(NLW_U0_s_axi_arsize_UNCONNECTED[2:0]),
        .s_axi_arvalid(NLW_U0_s_axi_arvalid_UNCONNECTED),
        .s_axi_awaddr(NLW_U0_s_axi_awaddr_UNCONNECTED[31:0]),
        .s_axi_awburst(NLW_U0_s_axi_awburst_UNCONNECTED[1:0]),
        .s_axi_awid(NLW_U0_s_axi_awid_UNCONNECTED[3:0]),
        .s_axi_awlen(NLW_U0_s_axi_awlen_UNCONNECTED[7:0]),
        .s_axi_awready(NLW_U0_s_axi_awready_UNCONNECTED),
        .s_axi_awsize(NLW_U0_s_axi_awsize_UNCONNECTED[2:0]),
        .s_axi_awvalid(NLW_U0_s_axi_awvalid_UNCONNECTED),
        .s_axi_bid(NLW_U0_s_axi_bid_UNCONNECTED[3:0]),
        .s_axi_bready(NLW_U0_s_axi_bready_UNCONNECTED),
        .s_axi_bresp(NLW_U0_s_axi_bresp_UNCONNECTED[1:0]),
        .s_axi_bvalid(NLW_U0_s_axi_bvalid_UNCONNECTED),
        .s_axi_dbiterr(NLW_U0_s_axi_dbiterr_UNCONNECTED),
        .s_axi_injectdbiterr(NLW_U0_s_axi_injectdbiterr_UNCONNECTED),
        .s_axi_injectsbiterr(NLW_U0_s_axi_injectsbiterr_UNCONNECTED),
        .s_axi_rdaddrecc(NLW_U0_s_axi_rdaddrecc_UNCONNECTED[7:0]),
        .s_axi_rdata(NLW_U0_s_axi_rdata_UNCONNECTED[7:0]),
        .s_axi_rid(NLW_U0_s_axi_rid_UNCONNECTED[3:0]),
        .s_axi_rlast(NLW_U0_s_axi_rlast_UNCONNECTED),
        .s_axi_rready(NLW_U0_s_axi_rready_UNCONNECTED),
        .s_axi_rresp(NLW_U0_s_axi_rresp_UNCONNECTED[1:0]),
        .s_axi_rvalid(NLW_U0_s_axi_rvalid_UNCONNECTED),
        .s_axi_sbiterr(NLW_U0_s_axi_sbiterr_UNCONNECTED),
        .s_axi_wdata(NLW_U0_s_axi_wdata_UNCONNECTED[7:0]),
        .s_axi_wlast(NLW_U0_s_axi_wlast_UNCONNECTED),
        .s_axi_wready(NLW_U0_s_axi_wready_UNCONNECTED),
        .s_axi_wstrb(NLW_U0_s_axi_wstrb_UNCONNECTED[0]),
        .s_axi_wvalid(NLW_U0_s_axi_wvalid_UNCONNECTED),
        .sbiterr(NLW_U0_sbiterr_UNCONNECTED),
        .shutdown(NLW_U0_shutdown_UNCONNECTED),
        .sleep(NLW_U0_sleep_UNCONNECTED),
        .wea(wea),
        .web(NLW_U0_web_UNCONNECTED[0]));
endmodule

(* ECO_CHECKSUM = "cebee17a" *) (* POWER_OPT_BRAM_CDC = "0" *) (* POWER_OPT_BRAM_SR_ADDR = "0" *) 
(* POWER_OPT_LOOPED_NET_PERCENTAGE = "0" *) 
(* NotValidForBitStream *)
(* \DesignAttr:ENABLE_NOC_NETLIST_VIEW  *) 
(* \DesignAttr:ENABLE_AIE_NETLIST_VIEW  *) 
module neander
   (clk,
    reset,
    parado,
    erro,
    estado,
    ac,
    pc,
    ri,
    rem,
    opcode,
    n,
    z,
    endereco_memoria,
    dado_memoria,
    resultado_ula);
  input clk;
  input reset;
  output parado;
  output erro;
  output [3:0]estado;
  output [7:0]ac;
  output [7:0]pc;
  output [7:0]ri;
  output [7:0]rem;
  output [3:0]opcode;
  output n;
  output z;
  output [7:0]endereco_memoria;
  output [7:0]dado_memoria;
  output [7:0]resultado_ula;

  wire [7:0]ac;
  wire [6:0]ac_OBUF;
  wire carga_rem;
  wire carga_ri;
  wire clk;
  wire clk_IBUF;
  wire clk_IBUF_BUFG;
  wire [7:0]dado_memoria;
  wire [7:0]dado_memoria_OBUF;
  wire [7:0]endereco_memoria;
  wire [7:0]endereco_memoria_OBUF;
  wire erro;
  wire erro_OBUF;
  wire escrita_ativa;
  wire [3:0]estado;
  wire [3:0]estado_OBUF;
  wire lopt;
  wire n;
  wire n_OBUF;
  wire [3:0]opcode;
  wire [3:0]opcode_OBUF;
  wire parado;
  wire parado_OBUF;
  wire [7:0]pc;
  wire [7:0]pc_OBUF;
  wire [7:0]rem;
  wire [7:0]rem_OBUF;
  wire reset;
  wire reset_IBUF;
  wire [7:0]resultado_ula;
  wire [7:0]resultado_ula_OBUF;
  wire [7:0]ri;
  wire [3:0]ri_OBUF;
  wire u_controle_n_0;
  wire u_controle_n_1;
  wire u_controle_n_15;
  wire u_controle_n_17;
  wire u_controle_n_2;
  wire u_controle_n_3;
  wire u_controle_n_5;
  wire u_controle_n_6;
  wire u_controle_n_7;
  wire u_dados_n_33;
  wire u_dados_n_34;
  wire u_dados_n_35;
  wire u_dados_n_36;
  wire u_dados_n_37;
  wire u_dados_n_38;
  wire u_dados_n_47;
  wire u_dados_n_56;
  wire u_dados_n_65;
  wire u_dados_n_66;
  wire z;
  wire NLW_u_dados_z_OBUF_UNCONNECTED;

initial begin
 $sdf_annotate("neander_multiplicacao_diag_tb_time_impl.sdf",,,,"tool_control");
end
  OBUF \ac_OBUF[0]_inst 
       (.I(ac_OBUF[0]),
        .O(ac[0]));
  OBUF \ac_OBUF[1]_inst 
       (.I(ac_OBUF[1]),
        .O(ac[1]));
  OBUF \ac_OBUF[2]_inst 
       (.I(ac_OBUF[2]),
        .O(ac[2]));
  OBUF \ac_OBUF[3]_inst 
       (.I(ac_OBUF[3]),
        .O(ac[3]));
  OBUF \ac_OBUF[4]_inst 
       (.I(ac_OBUF[4]),
        .O(ac[4]));
  OBUF \ac_OBUF[5]_inst 
       (.I(ac_OBUF[5]),
        .O(ac[5]));
  OBUF \ac_OBUF[6]_inst 
       (.I(ac_OBUF[6]),
        .O(ac[6]));
  OBUF \ac_OBUF[7]_inst 
       (.I(n_OBUF),
        .O(ac[7]));
  BUFG clk_IBUF_BUFG_inst
       (.I(clk_IBUF),
        .O(clk_IBUF_BUFG));
  IBUF clk_IBUF_inst
       (.I(clk),
        .O(clk_IBUF));
  OBUF \dado_memoria_OBUF[0]_inst 
       (.I(dado_memoria_OBUF[0]),
        .O(dado_memoria[0]));
  OBUF \dado_memoria_OBUF[1]_inst 
       (.I(dado_memoria_OBUF[1]),
        .O(dado_memoria[1]));
  OBUF \dado_memoria_OBUF[2]_inst 
       (.I(dado_memoria_OBUF[2]),
        .O(dado_memoria[2]));
  OBUF \dado_memoria_OBUF[3]_inst 
       (.I(dado_memoria_OBUF[3]),
        .O(dado_memoria[3]));
  OBUF \dado_memoria_OBUF[4]_inst 
       (.I(dado_memoria_OBUF[4]),
        .O(dado_memoria[4]));
  OBUF \dado_memoria_OBUF[5]_inst 
       (.I(dado_memoria_OBUF[5]),
        .O(dado_memoria[5]));
  OBUF \dado_memoria_OBUF[6]_inst 
       (.I(dado_memoria_OBUF[6]),
        .O(dado_memoria[6]));
  OBUF \dado_memoria_OBUF[7]_inst 
       (.I(dado_memoria_OBUF[7]),
        .O(dado_memoria[7]));
  OBUF \endereco_memoria_OBUF[0]_inst 
       (.I(endereco_memoria_OBUF[0]),
        .O(endereco_memoria[0]));
  OBUF \endereco_memoria_OBUF[1]_inst 
       (.I(endereco_memoria_OBUF[1]),
        .O(endereco_memoria[1]));
  OBUF \endereco_memoria_OBUF[2]_inst 
       (.I(endereco_memoria_OBUF[2]),
        .O(endereco_memoria[2]));
  OBUF \endereco_memoria_OBUF[3]_inst 
       (.I(endereco_memoria_OBUF[3]),
        .O(endereco_memoria[3]));
  OBUF \endereco_memoria_OBUF[4]_inst 
       (.I(endereco_memoria_OBUF[4]),
        .O(endereco_memoria[4]));
  OBUF \endereco_memoria_OBUF[5]_inst 
       (.I(endereco_memoria_OBUF[5]),
        .O(endereco_memoria[5]));
  OBUF \endereco_memoria_OBUF[6]_inst 
       (.I(endereco_memoria_OBUF[6]),
        .O(endereco_memoria[6]));
  OBUF \endereco_memoria_OBUF[7]_inst 
       (.I(endereco_memoria_OBUF[7]),
        .O(endereco_memoria[7]));
  OBUF erro_OBUF_inst
       (.I(erro_OBUF),
        .O(erro));
  OBUF \estado_OBUF[0]_inst 
       (.I(estado_OBUF[0]),
        .O(estado[0]));
  OBUF \estado_OBUF[1]_inst 
       (.I(estado_OBUF[1]),
        .O(estado[1]));
  OBUF \estado_OBUF[2]_inst 
       (.I(estado_OBUF[2]),
        .O(estado[2]));
  OBUF \estado_OBUF[3]_inst 
       (.I(estado_OBUF[3]),
        .O(estado[3]));
  OBUF n_OBUF_inst
       (.I(n_OBUF),
        .O(n));
  OBUF \opcode_OBUF[0]_inst 
       (.I(opcode_OBUF[0]),
        .O(opcode[0]));
  OBUF \opcode_OBUF[1]_inst 
       (.I(opcode_OBUF[1]),
        .O(opcode[1]));
  OBUF \opcode_OBUF[2]_inst 
       (.I(opcode_OBUF[2]),
        .O(opcode[2]));
  OBUF \opcode_OBUF[3]_inst 
       (.I(opcode_OBUF[3]),
        .O(opcode[3]));
  OBUF parado_OBUF_inst
       (.I(parado_OBUF),
        .O(parado));
  OBUF \pc_OBUF[0]_inst 
       (.I(pc_OBUF[0]),
        .O(pc[0]));
  OBUF \pc_OBUF[1]_inst 
       (.I(pc_OBUF[1]),
        .O(pc[1]));
  OBUF \pc_OBUF[2]_inst 
       (.I(pc_OBUF[2]),
        .O(pc[2]));
  OBUF \pc_OBUF[3]_inst 
       (.I(pc_OBUF[3]),
        .O(pc[3]));
  OBUF \pc_OBUF[4]_inst 
       (.I(pc_OBUF[4]),
        .O(pc[4]));
  OBUF \pc_OBUF[5]_inst 
       (.I(pc_OBUF[5]),
        .O(pc[5]));
  OBUF \pc_OBUF[6]_inst 
       (.I(pc_OBUF[6]),
        .O(pc[6]));
  OBUF \pc_OBUF[7]_inst 
       (.I(pc_OBUF[7]),
        .O(pc[7]));
  OBUF \rem_OBUF[0]_inst 
       (.I(rem_OBUF[0]),
        .O(rem[0]));
  OBUF \rem_OBUF[1]_inst 
       (.I(rem_OBUF[1]),
        .O(rem[1]));
  OBUF \rem_OBUF[2]_inst 
       (.I(rem_OBUF[2]),
        .O(rem[2]));
  OBUF \rem_OBUF[3]_inst 
       (.I(rem_OBUF[3]),
        .O(rem[3]));
  OBUF \rem_OBUF[4]_inst 
       (.I(rem_OBUF[4]),
        .O(rem[4]));
  OBUF \rem_OBUF[5]_inst 
       (.I(rem_OBUF[5]),
        .O(rem[5]));
  OBUF \rem_OBUF[6]_inst 
       (.I(rem_OBUF[6]),
        .O(rem[6]));
  OBUF \rem_OBUF[7]_inst 
       (.I(rem_OBUF[7]),
        .O(rem[7]));
  IBUF reset_IBUF_inst
       (.I(reset),
        .O(reset_IBUF));
  OBUF \resultado_ula_OBUF[0]_inst 
       (.I(resultado_ula_OBUF[0]),
        .O(resultado_ula[0]));
  OBUF \resultado_ula_OBUF[1]_inst 
       (.I(resultado_ula_OBUF[1]),
        .O(resultado_ula[1]));
  OBUF \resultado_ula_OBUF[2]_inst 
       (.I(resultado_ula_OBUF[2]),
        .O(resultado_ula[2]));
  OBUF \resultado_ula_OBUF[3]_inst 
       (.I(resultado_ula_OBUF[3]),
        .O(resultado_ula[3]));
  OBUF \resultado_ula_OBUF[4]_inst 
       (.I(resultado_ula_OBUF[4]),
        .O(resultado_ula[4]));
  OBUF \resultado_ula_OBUF[5]_inst 
       (.I(resultado_ula_OBUF[5]),
        .O(resultado_ula[5]));
  OBUF \resultado_ula_OBUF[6]_inst 
       (.I(resultado_ula_OBUF[6]),
        .O(resultado_ula[6]));
  OBUF \resultado_ula_OBUF[7]_inst 
       (.I(resultado_ula_OBUF[7]),
        .O(resultado_ula[7]));
  OBUF \ri_OBUF[0]_inst 
       (.I(ri_OBUF[0]),
        .O(ri[0]));
  OBUF \ri_OBUF[1]_inst 
       (.I(ri_OBUF[1]),
        .O(ri[1]));
  OBUF \ri_OBUF[2]_inst 
       (.I(ri_OBUF[2]),
        .O(ri[2]));
  OBUF \ri_OBUF[3]_inst 
       (.I(ri_OBUF[3]),
        .O(ri[3]));
  OBUF \ri_OBUF[4]_inst 
       (.I(opcode_OBUF[0]),
        .O(ri[4]));
  OBUF \ri_OBUF[5]_inst 
       (.I(opcode_OBUF[1]),
        .O(ri[5]));
  OBUF \ri_OBUF[6]_inst 
       (.I(opcode_OBUF[2]),
        .O(ri[6]));
  OBUF \ri_OBUF[7]_inst 
       (.I(opcode_OBUF[3]),
        .O(ri[7]));
  unidade_controle u_controle
       (.D({u_dados_n_33,u_dados_n_34,u_dados_n_35,u_dados_n_36,u_dados_n_37,u_dados_n_38}),
        .E(u_controle_n_15),
        .\FSM_onehot_estado_reg[0]_0 (u_dados_n_66),
        .\FSM_onehot_estado_reg[0]_1 (u_dados_n_47),
        .\FSM_onehot_estado_reg[11]_0 (u_dados_n_65),
        .Q({u_controle_n_0,u_controle_n_1,u_controle_n_2,u_controle_n_3,carga_rem,u_controle_n_5,u_controle_n_6,u_controle_n_7,carga_ri}),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .ena(u_controle_n_17),
        .erro_OBUF(erro_OBUF),
        .estado_OBUF(estado_OBUF),
        .parado_OBUF(parado_OBUF),
        .\pc_reg[7] (u_dados_n_56),
        .reset_IBUF(reset_IBUF),
        .wea(escrita_ativa));
  caminho_dados u_dados
       (.D({u_dados_n_33,u_dados_n_34,u_dados_n_35,u_dados_n_36,u_dados_n_37,u_dados_n_38}),
        .E(u_controle_n_15),
        .\FSM_onehot_estado_reg[6] (u_dados_n_65),
        .Q(ac_OBUF),
        .addra(endereco_memoria_OBUF),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .douta(dado_memoria_OBUF),
        .ena(u_controle_n_17),
        .lopt(lopt),
        .n_OBUF(n_OBUF),
        .\pc[7]_i_3 ({u_controle_n_0,u_controle_n_1,u_controle_n_2,u_controle_n_3,carga_rem,u_controle_n_5,u_controle_n_6,u_controle_n_7,carga_ri}),
        .\pc_reg[7] (pc_OBUF),
        .\rem_reg[7] (rem_OBUF),
        .reset_IBUF(reset_IBUF),
        .resultado_ula_OBUF(resultado_ula_OBUF),
        .\ri_reg[4] (u_dados_n_66),
        .\ri_reg[6] (u_dados_n_47),
        .\ri_reg[7] ({opcode_OBUF,ri_OBUF}),
        .wea(escrita_ativa),
        .z_OBUF(NLW_u_dados_z_OBUF_UNCONNECTED),
        .z_reg(u_dados_n_56));
  (* OPT_MODIFIED = "SWEEP" *) 
  OBUF z_OBUF_inst
       (.I(lopt),
        .O(z));
endmodule

module registrador_endereco
   (D,
    \rem_reg[7]_0 ,
    \pc_reg[0] ,
    \pc_reg[0]_0 ,
    reset_IBUF,
    \rem_reg[0]_0 ,
    \rem_reg[7]_1 ,
    clk_IBUF_BUFG);
  output [0:0]D;
  output [7:0]\rem_reg[7]_0 ;
  input \pc_reg[0] ;
  input [0:0]\pc_reg[0]_0 ;
  input reset_IBUF;
  input [0:0]\rem_reg[0]_0 ;
  input [7:0]\rem_reg[7]_1 ;
  input clk_IBUF_BUFG;

  wire [0:0]D;
  wire clk_IBUF_BUFG;
  wire \pc_reg[0] ;
  wire [0:0]\pc_reg[0]_0 ;
  wire [0:0]\rem_reg[0]_0 ;
  wire [7:0]\rem_reg[7]_0 ;
  wire [7:0]\rem_reg[7]_1 ;
  wire reset_IBUF;

  LUT3 #(
    .INIT(8'h8B)) 
    \pc[0]_i_1 
       (.I0(\rem_reg[7]_0 [0]),
        .I1(\pc_reg[0] ),
        .I2(\pc_reg[0]_0 ),
        .O(D));
  FDRE #(
    .INIT(1'b0)) 
    \rem_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(\rem_reg[0]_0 ),
        .D(\rem_reg[7]_1 [0]),
        .Q(\rem_reg[7]_0 [0]),
        .R(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \rem_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(\rem_reg[0]_0 ),
        .D(\rem_reg[7]_1 [1]),
        .Q(\rem_reg[7]_0 [1]),
        .R(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \rem_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(\rem_reg[0]_0 ),
        .D(\rem_reg[7]_1 [2]),
        .Q(\rem_reg[7]_0 [2]),
        .R(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \rem_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(\rem_reg[0]_0 ),
        .D(\rem_reg[7]_1 [3]),
        .Q(\rem_reg[7]_0 [3]),
        .R(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \rem_reg[4] 
       (.C(clk_IBUF_BUFG),
        .CE(\rem_reg[0]_0 ),
        .D(\rem_reg[7]_1 [4]),
        .Q(\rem_reg[7]_0 [4]),
        .R(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \rem_reg[5] 
       (.C(clk_IBUF_BUFG),
        .CE(\rem_reg[0]_0 ),
        .D(\rem_reg[7]_1 [5]),
        .Q(\rem_reg[7]_0 [5]),
        .R(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \rem_reg[6] 
       (.C(clk_IBUF_BUFG),
        .CE(\rem_reg[0]_0 ),
        .D(\rem_reg[7]_1 [6]),
        .Q(\rem_reg[7]_0 [6]),
        .R(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \rem_reg[7] 
       (.C(clk_IBUF_BUFG),
        .CE(\rem_reg[0]_0 ),
        .D(\rem_reg[7]_1 [7]),
        .Q(\rem_reg[7]_0 [7]),
        .R(reset_IBUF));
endmodule

module registrador_flags
   (z_OBUF,
    reset_IBUF,
    E,
    z_in,
    clk_IBUF_BUFG,
    lopt);
  output z_OBUF;
  input reset_IBUF;
  input [0:0]E;
  input z_in;
  input clk_IBUF_BUFG;
  output lopt;

  wire [0:0]E;
  wire clk_IBUF_BUFG;
  wire reset_IBUF;
  wire z_OBUF;
  wire z_in;
  wire z_reg_lopt_replica_1;

  assign lopt = z_reg_lopt_replica_1;
  FDSE #(
    .INIT(1'b1)) 
    z_reg
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(z_in),
        .Q(z_OBUF),
        .S(reset_IBUF));
  (* OPT_INSERTED_REPDRIVER *) 
  (* OPT_MODIFIED = "SWEEP" *) 
  FDSE #(
    .INIT(1'b1)) 
    z_reg_lopt_replica
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(z_in),
        .Q(z_reg_lopt_replica_1),
        .S(reset_IBUF));
endmodule

module registrador_instrucao
   (D,
    Q,
    \ri_reg[6]_0 ,
    z_in,
    resultado_ula_OBUF,
    \ri_reg[6]_1 ,
    \ri_reg[7]_0 ,
    z_reg,
    \FSM_onehot_estado_reg[6] ,
    \ri_reg[6]_2 ,
    \ri_reg[4]_0 ,
    E,
    \pc[7]_i_3_0 ,
    z_reg_0,
    \q_reg[0] ,
    \q_reg[3] ,
    \q_reg[1] ,
    \q_reg[2] ,
    z_reg_1,
    \q_reg[4] ,
    \q_reg[5] ,
    z_OBUF,
    reset_IBUF,
    dina,
    \ri_reg[7]_1 ,
    clk_IBUF_BUFG);
  output [5:0]D;
  output [7:0]Q;
  output \ri_reg[6]_0 ;
  output z_in;
  output [6:0]resultado_ula_OBUF;
  output \ri_reg[6]_1 ;
  output \ri_reg[7]_0 ;
  output z_reg;
  output \FSM_onehot_estado_reg[6] ;
  output \ri_reg[6]_2 ;
  output \ri_reg[4]_0 ;
  output [0:0]E;
  input [6:0]\pc[7]_i_3_0 ;
  input [0:0]z_reg_0;
  input \q_reg[0] ;
  input \q_reg[3] ;
  input \q_reg[1] ;
  input \q_reg[2] ;
  input z_reg_1;
  input \q_reg[4] ;
  input \q_reg[5] ;
  input z_OBUF;
  input reset_IBUF;
  input [7:0]dina;
  input [7:0]\ri_reg[7]_1 ;
  input clk_IBUF_BUFG;

  wire [5:0]D;
  wire [0:0]E;
  wire \FSM_onehot_estado_reg[6] ;
  wire [7:0]Q;
  wire clk_IBUF_BUFG;
  wire [7:0]dina;
  wire [6:0]\pc[7]_i_3_0 ;
  wire \pc[7]_i_5_n_0 ;
  wire \q_reg[0] ;
  wire \q_reg[1] ;
  wire \q_reg[2] ;
  wire \q_reg[3] ;
  wire \q_reg[4] ;
  wire \q_reg[5] ;
  wire reset_IBUF;
  wire [6:0]resultado_ula_OBUF;
  wire \resultado_ula_OBUF[0]_inst_i_3_n_0 ;
  wire \resultado_ula_OBUF[1]_inst_i_3_n_0 ;
  wire \resultado_ula_OBUF[2]_inst_i_3_n_0 ;
  wire \resultado_ula_OBUF[3]_inst_i_3_n_0 ;
  wire \resultado_ula_OBUF[4]_inst_i_3_n_0 ;
  wire \resultado_ula_OBUF[5]_inst_i_3_n_0 ;
  wire \resultado_ula_OBUF[6]_inst_i_2_n_0 ;
  wire \resultado_ula_OBUF[6]_inst_i_4_n_0 ;
  wire \ri_reg[4]_0 ;
  wire \ri_reg[6]_0 ;
  wire \ri_reg[6]_1 ;
  wire \ri_reg[6]_2 ;
  wire \ri_reg[7]_0 ;
  wire [7:0]\ri_reg[7]_1 ;
  wire z_OBUF;
  wire z_i_2_n_0;
  wire z_i_3_n_0;
  wire z_in;
  wire z_reg;
  wire [0:0]z_reg_0;
  wire z_reg_1;

  LUT3 #(
    .INIT(8'hEF)) 
    \FSM_onehot_estado[0]_i_2 
       (.I0(Q[4]),
        .I1(Q[7]),
        .I2(\pc[7]_i_3_0 [1]),
        .O(\ri_reg[4]_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \FSM_onehot_estado[0]_i_3 
       (.I0(Q[6]),
        .I1(Q[5]),
        .O(\ri_reg[6]_0 ));
  LUT5 #(
    .INIT(32'h00404040)) 
    \FSM_onehot_estado[10]_i_1 
       (.I0(Q[6]),
        .I1(Q[7]),
        .I2(\pc[7]_i_3_0 [4]),
        .I3(Q[4]),
        .I4(Q[5]),
        .O(D[5]));
  LUT6 #(
    .INIT(64'h88C8EAC8C8000022)) 
    \FSM_onehot_estado[11]_i_2 
       (.I0(\pc[7]_i_3_0 [4]),
        .I1(Q[7]),
        .I2(\pc[7]_i_3_0 [1]),
        .I3(Q[5]),
        .I4(Q[4]),
        .I5(Q[6]),
        .O(\FSM_onehot_estado_reg[6] ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT5 #(
    .INIT(32'h00000080)) 
    \FSM_onehot_estado[3]_i_1 
       (.I0(Q[5]),
        .I1(Q[6]),
        .I2(\pc[7]_i_3_0 [1]),
        .I3(Q[7]),
        .I4(Q[4]),
        .O(D[0]));
  LUT6 #(
    .INIT(64'hEAAAAAAAAAAAAAAA)) 
    \FSM_onehot_estado[4]_i_1 
       (.I0(\pc[7]_i_3_0 [3]),
        .I1(Q[7]),
        .I2(\pc[7]_i_3_0 [1]),
        .I3(Q[5]),
        .I4(Q[6]),
        .I5(Q[4]),
        .O(D[1]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT5 #(
    .INIT(32'h0222AA28)) 
    \FSM_onehot_estado[5]_i_1 
       (.I0(\pc[7]_i_3_0 [1]),
        .I1(Q[6]),
        .I2(Q[5]),
        .I3(Q[4]),
        .I4(Q[7]),
        .O(D[2]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT5 #(
    .INIT(32'h22200220)) 
    \FSM_onehot_estado[7]_i_1 
       (.I0(\pc[7]_i_3_0 [4]),
        .I1(Q[7]),
        .I2(Q[5]),
        .I3(Q[6]),
        .I4(Q[4]),
        .O(D[3]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT5 #(
    .INIT(32'h00100000)) 
    \FSM_onehot_estado[9]_i_1 
       (.I0(Q[5]),
        .I1(Q[6]),
        .I2(\pc[7]_i_3_0 [4]),
        .I3(Q[7]),
        .I4(Q[4]),
        .O(D[4]));
  LUT4 #(
    .INIT(16'h002F)) 
    \pc[7]_i_3 
       (.I0(z_OBUF),
        .I1(Q[4]),
        .I2(Q[5]),
        .I3(\pc[7]_i_5_n_0 ),
        .O(z_reg));
  LUT6 #(
    .INIT(64'hFFDFFFFFFFDFFFDF)) 
    \pc[7]_i_5 
       (.I0(\pc[7]_i_3_0 [6]),
        .I1(reset_IBUF),
        .I2(Q[7]),
        .I3(Q[6]),
        .I4(dina[7]),
        .I5(Q[4]),
        .O(\pc[7]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF00BCFFFF0000)) 
    \q[6]_i_1 
       (.I0(Q[4]),
        .I1(Q[6]),
        .I2(Q[5]),
        .I3(Q[7]),
        .I4(\pc[7]_i_3_0 [2]),
        .I5(\pc[7]_i_3_0 [5]),
        .O(E));
  MUXF7 \resultado_ula_OBUF[0]_inst_i_1 
       (.I0(\q_reg[0] ),
        .I1(\resultado_ula_OBUF[0]_inst_i_3_n_0 ),
        .O(resultado_ula_OBUF[0]),
        .S(\ri_reg[6]_1 ));
  LUT6 #(
    .INIT(64'h33333333333333E3)) 
    \resultado_ula_OBUF[0]_inst_i_3 
       (.I0(\ri_reg[7]_1 [0]),
        .I1(dina[0]),
        .I2(Q[6]),
        .I3(Q[5]),
        .I4(Q[4]),
        .I5(Q[7]),
        .O(\resultado_ula_OBUF[0]_inst_i_3_n_0 ));
  MUXF7 \resultado_ula_OBUF[1]_inst_i_1 
       (.I0(\q_reg[1] ),
        .I1(\resultado_ula_OBUF[1]_inst_i_3_n_0 ),
        .O(resultado_ula_OBUF[1]),
        .S(\ri_reg[6]_1 ));
  LUT6 #(
    .INIT(64'h33333333333333E3)) 
    \resultado_ula_OBUF[1]_inst_i_3 
       (.I0(\ri_reg[7]_1 [1]),
        .I1(dina[1]),
        .I2(Q[6]),
        .I3(Q[5]),
        .I4(Q[4]),
        .I5(Q[7]),
        .O(\resultado_ula_OBUF[1]_inst_i_3_n_0 ));
  MUXF7 \resultado_ula_OBUF[2]_inst_i_1 
       (.I0(\q_reg[2] ),
        .I1(\resultado_ula_OBUF[2]_inst_i_3_n_0 ),
        .O(resultado_ula_OBUF[2]),
        .S(\ri_reg[6]_1 ));
  LUT6 #(
    .INIT(64'h33333333333333E3)) 
    \resultado_ula_OBUF[2]_inst_i_3 
       (.I0(\ri_reg[7]_1 [2]),
        .I1(dina[2]),
        .I2(Q[6]),
        .I3(Q[5]),
        .I4(Q[4]),
        .I5(Q[7]),
        .O(\resultado_ula_OBUF[2]_inst_i_3_n_0 ));
  MUXF7 \resultado_ula_OBUF[3]_inst_i_1 
       (.I0(\q_reg[3] ),
        .I1(\resultado_ula_OBUF[3]_inst_i_3_n_0 ),
        .O(resultado_ula_OBUF[3]),
        .S(\ri_reg[6]_1 ));
  LUT6 #(
    .INIT(64'h33333333333333E3)) 
    \resultado_ula_OBUF[3]_inst_i_3 
       (.I0(\ri_reg[7]_1 [3]),
        .I1(dina[3]),
        .I2(Q[6]),
        .I3(Q[5]),
        .I4(Q[4]),
        .I5(Q[7]),
        .O(\resultado_ula_OBUF[3]_inst_i_3_n_0 ));
  MUXF7 \resultado_ula_OBUF[4]_inst_i_1 
       (.I0(\q_reg[4] ),
        .I1(\resultado_ula_OBUF[4]_inst_i_3_n_0 ),
        .O(resultado_ula_OBUF[4]),
        .S(\ri_reg[6]_1 ));
  LUT6 #(
    .INIT(64'h33333333333333E3)) 
    \resultado_ula_OBUF[4]_inst_i_3 
       (.I0(\ri_reg[7]_1 [4]),
        .I1(dina[4]),
        .I2(Q[6]),
        .I3(Q[5]),
        .I4(Q[4]),
        .I5(Q[7]),
        .O(\resultado_ula_OBUF[4]_inst_i_3_n_0 ));
  MUXF7 \resultado_ula_OBUF[5]_inst_i_1 
       (.I0(\q_reg[5] ),
        .I1(\resultado_ula_OBUF[5]_inst_i_3_n_0 ),
        .O(resultado_ula_OBUF[5]),
        .S(\ri_reg[6]_1 ));
  LUT6 #(
    .INIT(64'h33333333333333E3)) 
    \resultado_ula_OBUF[5]_inst_i_3 
       (.I0(\ri_reg[7]_1 [5]),
        .I1(dina[5]),
        .I2(Q[6]),
        .I3(Q[5]),
        .I4(Q[4]),
        .I5(Q[7]),
        .O(\resultado_ula_OBUF[5]_inst_i_3_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \resultado_ula_OBUF[6]_inst_i_1 
       (.I0(\resultado_ula_OBUF[6]_inst_i_2_n_0 ),
        .O(resultado_ula_OBUF[6]));
  MUXF7 \resultado_ula_OBUF[6]_inst_i_2 
       (.I0(z_reg_1),
        .I1(\resultado_ula_OBUF[6]_inst_i_4_n_0 ),
        .O(\resultado_ula_OBUF[6]_inst_i_2_n_0 ),
        .S(\ri_reg[6]_1 ));
  LUT6 #(
    .INIT(64'hFFFDFFFD00000002)) 
    \resultado_ula_OBUF[6]_inst_i_4 
       (.I0(Q[6]),
        .I1(Q[5]),
        .I2(Q[4]),
        .I3(Q[7]),
        .I4(\ri_reg[7]_1 [6]),
        .I5(dina[6]),
        .O(\resultado_ula_OBUF[6]_inst_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h02)) 
    \resultado_ula_OBUF[7]_inst_i_2 
       (.I0(Q[6]),
        .I1(Q[4]),
        .I2(Q[7]),
        .O(\ri_reg[6]_1 ));
  LUT3 #(
    .INIT(8'h08)) 
    \resultado_ula_OBUF[7]_inst_i_4 
       (.I0(Q[6]),
        .I1(Q[4]),
        .I2(Q[7]),
        .O(\ri_reg[6]_2 ));
  LUT4 #(
    .INIT(16'hEBBF)) 
    \resultado_ula_OBUF[7]_inst_i_5 
       (.I0(Q[7]),
        .I1(Q[5]),
        .I2(Q[6]),
        .I3(Q[4]),
        .O(\ri_reg[7]_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \ri_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(\pc[7]_i_3_0 [0]),
        .D(\ri_reg[7]_1 [0]),
        .Q(Q[0]),
        .R(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \ri_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(\pc[7]_i_3_0 [0]),
        .D(\ri_reg[7]_1 [1]),
        .Q(Q[1]),
        .R(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \ri_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(\pc[7]_i_3_0 [0]),
        .D(\ri_reg[7]_1 [2]),
        .Q(Q[2]),
        .R(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \ri_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(\pc[7]_i_3_0 [0]),
        .D(\ri_reg[7]_1 [3]),
        .Q(Q[3]),
        .R(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \ri_reg[4] 
       (.C(clk_IBUF_BUFG),
        .CE(\pc[7]_i_3_0 [0]),
        .D(\ri_reg[7]_1 [4]),
        .Q(Q[4]),
        .R(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \ri_reg[5] 
       (.C(clk_IBUF_BUFG),
        .CE(\pc[7]_i_3_0 [0]),
        .D(\ri_reg[7]_1 [5]),
        .Q(Q[5]),
        .R(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \ri_reg[6] 
       (.C(clk_IBUF_BUFG),
        .CE(\pc[7]_i_3_0 [0]),
        .D(\ri_reg[7]_1 [6]),
        .Q(Q[6]),
        .R(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \ri_reg[7] 
       (.C(clk_IBUF_BUFG),
        .CE(\pc[7]_i_3_0 [0]),
        .D(\ri_reg[7]_1 [7]),
        .Q(Q[7]),
        .R(reset_IBUF));
  LUT6 #(
    .INIT(64'h0000000000000010)) 
    z_i_1
       (.I0(resultado_ula_OBUF[2]),
        .I1(resultado_ula_OBUF[0]),
        .I2(z_i_2_n_0),
        .I3(z_i_3_n_0),
        .I4(z_reg_0),
        .I5(resultado_ula_OBUF[5]),
        .O(z_in));
  LUT5 #(
    .INIT(32'h000ACC0A)) 
    z_i_2
       (.I0(z_reg_1),
        .I1(\resultado_ula_OBUF[6]_inst_i_4_n_0 ),
        .I2(\q_reg[4] ),
        .I3(\ri_reg[6]_1 ),
        .I4(\resultado_ula_OBUF[4]_inst_i_3_n_0 ),
        .O(z_i_2_n_0));
  LUT5 #(
    .INIT(32'hFFFACCFA)) 
    z_i_3
       (.I0(\q_reg[3] ),
        .I1(\resultado_ula_OBUF[3]_inst_i_3_n_0 ),
        .I2(\q_reg[1] ),
        .I3(\ri_reg[6]_1 ),
        .I4(\resultado_ula_OBUF[1]_inst_i_3_n_0 ),
        .O(z_i_3_n_0));
endmodule

module ula
   (\q_reg[6] ,
    O,
    \q_reg[0] ,
    \q_reg[1] ,
    \q_reg[2] ,
    \q_reg[3] ,
    dina,
    \resultado_ula_OBUF[0]_inst_i_2_0 ,
    \resultado_ula_OBUF[4]_inst_i_2 ,
    \resultado_ula_OBUF[0]_inst_i_2_1 ,
    S,
    \q_reg[0]_0 ,
    douta,
    \q_reg[0]_1 );
  output [3:0]\q_reg[6] ;
  output [3:0]O;
  output \q_reg[0] ;
  output \q_reg[1] ;
  output \q_reg[2] ;
  output \q_reg[3] ;
  input [6:0]dina;
  input [3:0]\resultado_ula_OBUF[0]_inst_i_2_0 ;
  input [3:0]\resultado_ula_OBUF[4]_inst_i_2 ;
  input [3:0]\resultado_ula_OBUF[0]_inst_i_2_1 ;
  input [3:0]S;
  input \q_reg[0]_0 ;
  input [3:0]douta;
  input \q_reg[0]_1 ;

  wire [3:0]O;
  wire [3:0]S;
  wire [3:0]data1;
  wire [3:0]data2;
  wire [6:0]dina;
  wire [3:0]douta;
  wire \q_reg[0] ;
  wire \q_reg[0]_0 ;
  wire \q_reg[0]_1 ;
  wire \q_reg[1] ;
  wire \q_reg[2] ;
  wire \q_reg[3] ;
  wire [3:0]\q_reg[6] ;
  wire resultado0_carry_n_0;
  wire \resultado0_inferred__0/i__carry_n_0 ;
  wire [3:0]\resultado_ula_OBUF[0]_inst_i_2_0 ;
  wire [3:0]\resultado_ula_OBUF[0]_inst_i_2_1 ;
  wire [3:0]\resultado_ula_OBUF[4]_inst_i_2 ;
  wire [2:0]NLW_resultado0_carry_CO_UNCONNECTED;
  wire [3:0]NLW_resultado0_carry__0_CO_UNCONNECTED;
  wire [2:0]\NLW_resultado0_inferred__0/i__carry_CO_UNCONNECTED ;
  wire [3:0]\NLW_resultado0_inferred__0/i__carry__0_CO_UNCONNECTED ;

  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 resultado0_carry
       (.CI(1'b0),
        .CO({resultado0_carry_n_0,NLW_resultado0_carry_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI(dina[3:0]),
        .O(data1),
        .S(\resultado_ula_OBUF[0]_inst_i_2_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 resultado0_carry__0
       (.CI(resultado0_carry_n_0),
        .CO(NLW_resultado0_carry__0_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,dina[6:4]}),
        .O(\q_reg[6] ),
        .S(\resultado_ula_OBUF[4]_inst_i_2 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \resultado0_inferred__0/i__carry 
       (.CI(1'b0),
        .CO({\resultado0_inferred__0/i__carry_n_0 ,\NLW_resultado0_inferred__0/i__carry_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b1),
        .DI(dina[3:0]),
        .O(data2),
        .S(\resultado_ula_OBUF[0]_inst_i_2_1 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \resultado0_inferred__0/i__carry__0 
       (.CI(\resultado0_inferred__0/i__carry_n_0 ),
        .CO(\NLW_resultado0_inferred__0/i__carry__0_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,dina[6:4]}),
        .O(O),
        .S(S));
  LUT6 #(
    .INIT(64'hAFA0CF0FAFA0C000)) 
    \resultado_ula_OBUF[0]_inst_i_2 
       (.I0(data2[0]),
        .I1(dina[0]),
        .I2(\q_reg[0]_0 ),
        .I3(douta[0]),
        .I4(\q_reg[0]_1 ),
        .I5(data1[0]),
        .O(\q_reg[0] ));
  LUT6 #(
    .INIT(64'hAFA0CF0FAFA0C000)) 
    \resultado_ula_OBUF[1]_inst_i_2 
       (.I0(data2[1]),
        .I1(dina[1]),
        .I2(\q_reg[0]_0 ),
        .I3(douta[1]),
        .I4(\q_reg[0]_1 ),
        .I5(data1[1]),
        .O(\q_reg[1] ));
  LUT6 #(
    .INIT(64'hAFA0CF0FAFA0C000)) 
    \resultado_ula_OBUF[2]_inst_i_2 
       (.I0(data2[2]),
        .I1(dina[2]),
        .I2(\q_reg[0]_0 ),
        .I3(douta[2]),
        .I4(\q_reg[0]_1 ),
        .I5(data1[2]),
        .O(\q_reg[2] ));
  LUT6 #(
    .INIT(64'hAFA0CF0FAFA0C000)) 
    \resultado_ula_OBUF[3]_inst_i_2 
       (.I0(data2[3]),
        .I1(dina[3]),
        .I2(\q_reg[0]_0 ),
        .I3(douta[3]),
        .I4(\q_reg[0]_1 ),
        .I5(data1[3]),
        .O(\q_reg[3] ));
endmodule

module unidade_controle
   (Q,
    estado_OBUF,
    erro_OBUF,
    wea,
    E,
    parado_OBUF,
    ena,
    \FSM_onehot_estado_reg[0]_0 ,
    \FSM_onehot_estado_reg[0]_1 ,
    reset_IBUF,
    \FSM_onehot_estado_reg[11]_0 ,
    \pc_reg[7] ,
    clk_IBUF_BUFG,
    D);
  output [8:0]Q;
  output [3:0]estado_OBUF;
  output erro_OBUF;
  output [0:0]wea;
  output [0:0]E;
  output parado_OBUF;
  output ena;
  input \FSM_onehot_estado_reg[0]_0 ;
  input \FSM_onehot_estado_reg[0]_1 ;
  input reset_IBUF;
  input \FSM_onehot_estado_reg[11]_0 ;
  input \pc_reg[7] ;
  input clk_IBUF_BUFG;
  input [5:0]D;

  wire [5:0]D;
  wire [0:0]E;
  wire \FSM_onehot_estado[0]_i_1_n_0 ;
  wire \FSM_onehot_estado[11]_i_1_n_0 ;
  wire \FSM_onehot_estado_reg[0]_0 ;
  wire \FSM_onehot_estado_reg[0]_1 ;
  wire \FSM_onehot_estado_reg[11]_0 ;
  wire \FSM_onehot_estado_reg_n_0_[0] ;
  wire \FSM_onehot_estado_reg_n_0_[11] ;
  wire \FSM_onehot_estado_reg_n_0_[5] ;
  wire [8:0]Q;
  wire clk_IBUF_BUFG;
  wire ena;
  wire erro_OBUF;
  wire [3:0]estado_OBUF;
  wire parado_OBUF;
  wire \pc_reg[7] ;
  wire reset_IBUF;
  wire [0:0]wea;

  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFF4)) 
    \FSM_onehot_estado[0]_i_1 
       (.I0(\FSM_onehot_estado_reg[0]_0 ),
        .I1(\FSM_onehot_estado_reg[0]_1 ),
        .I2(Q[7]),
        .I3(Q[6]),
        .I4(Q[8]),
        .I5(Q[2]),
        .O(\FSM_onehot_estado[0]_i_1_n_0 ));
  (* \PinAttr:I0:HOLD_DETOUR  = "193" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \FSM_onehot_estado[11]_i_1 
       (.I0(\FSM_onehot_estado_reg_n_0_[11] ),
        .I1(\FSM_onehot_estado_reg[11]_0 ),
        .O(\FSM_onehot_estado[11]_i_1_n_0 ));
  (* FSM_ENCODED_STATES = "CAPTURA_ENDERECO:000001000000,BUSCA_ENDERECO:000000100000,DECODIFICA:000000000100,ERRO:100000000000,PARADO:000000010000,CAPTURA_INSTRUCAO:000000000010,BUSCA_INSTRUCAO:000000000001,EXECUTA_NOT:000000001000,ESCREVE_MEMORIA:001000000000,EXECUTA_ULA:000100000000,DESVIO:010000000000,LE_OPERANDO:000010000000" *) 
  FDSE #(
    .INIT(1'b1)) 
    \FSM_onehot_estado_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\FSM_onehot_estado[0]_i_1_n_0 ),
        .Q(\FSM_onehot_estado_reg_n_0_[0] ),
        .S(reset_IBUF));
  (* FSM_ENCODED_STATES = "CAPTURA_ENDERECO:000001000000,BUSCA_ENDERECO:000000100000,DECODIFICA:000000000100,ERRO:100000000000,PARADO:000000010000,CAPTURA_INSTRUCAO:000000000010,BUSCA_INSTRUCAO:000000000001,EXECUTA_NOT:000000001000,ESCREVE_MEMORIA:001000000000,EXECUTA_ULA:000100000000,DESVIO:010000000000,LE_OPERANDO:000010000000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_estado_reg[10] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(D[5]),
        .Q(Q[8]),
        .R(reset_IBUF));
  (* FSM_ENCODED_STATES = "CAPTURA_ENDERECO:000001000000,BUSCA_ENDERECO:000000100000,DECODIFICA:000000000100,ERRO:100000000000,PARADO:000000010000,CAPTURA_INSTRUCAO:000000000010,BUSCA_INSTRUCAO:000000000001,EXECUTA_NOT:000000001000,ESCREVE_MEMORIA:001000000000,EXECUTA_ULA:000100000000,DESVIO:010000000000,LE_OPERANDO:000010000000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_estado_reg[11] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\FSM_onehot_estado[11]_i_1_n_0 ),
        .Q(\FSM_onehot_estado_reg_n_0_[11] ),
        .R(reset_IBUF));
  (* FSM_ENCODED_STATES = "CAPTURA_ENDERECO:000001000000,BUSCA_ENDERECO:000000100000,DECODIFICA:000000000100,ERRO:100000000000,PARADO:000000010000,CAPTURA_INSTRUCAO:000000000010,BUSCA_INSTRUCAO:000000000001,EXECUTA_NOT:000000001000,ESCREVE_MEMORIA:001000000000,EXECUTA_ULA:000100000000,DESVIO:010000000000,LE_OPERANDO:000010000000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_estado_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\FSM_onehot_estado_reg_n_0_[0] ),
        .Q(Q[0]),
        .R(reset_IBUF));
  (* FSM_ENCODED_STATES = "CAPTURA_ENDERECO:000001000000,BUSCA_ENDERECO:000000100000,DECODIFICA:000000000100,ERRO:100000000000,PARADO:000000010000,CAPTURA_INSTRUCAO:000000000010,BUSCA_INSTRUCAO:000000000001,EXECUTA_NOT:000000001000,ESCREVE_MEMORIA:001000000000,EXECUTA_ULA:000100000000,DESVIO:010000000000,LE_OPERANDO:000010000000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_estado_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(Q[0]),
        .Q(Q[1]),
        .R(reset_IBUF));
  (* FSM_ENCODED_STATES = "CAPTURA_ENDERECO:000001000000,BUSCA_ENDERECO:000000100000,DECODIFICA:000000000100,ERRO:100000000000,PARADO:000000010000,CAPTURA_INSTRUCAO:000000000010,BUSCA_INSTRUCAO:000000000001,EXECUTA_NOT:000000001000,ESCREVE_MEMORIA:001000000000,EXECUTA_ULA:000100000000,DESVIO:010000000000,LE_OPERANDO:000010000000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_estado_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(D[0]),
        .Q(Q[2]),
        .R(reset_IBUF));
  (* FSM_ENCODED_STATES = "CAPTURA_ENDERECO:000001000000,BUSCA_ENDERECO:000000100000,DECODIFICA:000000000100,ERRO:100000000000,PARADO:000000010000,CAPTURA_INSTRUCAO:000000000010,BUSCA_INSTRUCAO:000000000001,EXECUTA_NOT:000000001000,ESCREVE_MEMORIA:001000000000,EXECUTA_ULA:000100000000,DESVIO:010000000000,LE_OPERANDO:000010000000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_estado_reg[4] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(D[1]),
        .Q(Q[3]),
        .R(reset_IBUF));
  (* FSM_ENCODED_STATES = "CAPTURA_ENDERECO:000001000000,BUSCA_ENDERECO:000000100000,DECODIFICA:000000000100,ERRO:100000000000,PARADO:000000010000,CAPTURA_INSTRUCAO:000000000010,BUSCA_INSTRUCAO:000000000001,EXECUTA_NOT:000000001000,ESCREVE_MEMORIA:001000000000,EXECUTA_ULA:000100000000,DESVIO:010000000000,LE_OPERANDO:000010000000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_estado_reg[5] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(D[2]),
        .Q(\FSM_onehot_estado_reg_n_0_[5] ),
        .R(reset_IBUF));
  (* FSM_ENCODED_STATES = "CAPTURA_ENDERECO:000001000000,BUSCA_ENDERECO:000000100000,DECODIFICA:000000000100,ERRO:100000000000,PARADO:000000010000,CAPTURA_INSTRUCAO:000000000010,BUSCA_INSTRUCAO:000000000001,EXECUTA_NOT:000000001000,ESCREVE_MEMORIA:001000000000,EXECUTA_ULA:000100000000,DESVIO:010000000000,LE_OPERANDO:000010000000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_estado_reg[6] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\FSM_onehot_estado_reg_n_0_[5] ),
        .Q(Q[4]),
        .R(reset_IBUF));
  (* FSM_ENCODED_STATES = "CAPTURA_ENDERECO:000001000000,BUSCA_ENDERECO:000000100000,DECODIFICA:000000000100,ERRO:100000000000,PARADO:000000010000,CAPTURA_INSTRUCAO:000000000010,BUSCA_INSTRUCAO:000000000001,EXECUTA_NOT:000000001000,ESCREVE_MEMORIA:001000000000,EXECUTA_ULA:000100000000,DESVIO:010000000000,LE_OPERANDO:000010000000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_estado_reg[7] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(D[3]),
        .Q(Q[5]),
        .R(reset_IBUF));
  (* FSM_ENCODED_STATES = "CAPTURA_ENDERECO:000001000000,BUSCA_ENDERECO:000000100000,DECODIFICA:000000000100,ERRO:100000000000,PARADO:000000010000,CAPTURA_INSTRUCAO:000000000010,BUSCA_INSTRUCAO:000000000001,EXECUTA_NOT:000000001000,ESCREVE_MEMORIA:001000000000,EXECUTA_ULA:000100000000,DESVIO:010000000000,LE_OPERANDO:000010000000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_estado_reg[8] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(Q[5]),
        .Q(Q[6]),
        .R(reset_IBUF));
  (* FSM_ENCODED_STATES = "CAPTURA_ENDERECO:000001000000,BUSCA_ENDERECO:000000100000,DECODIFICA:000000000100,ERRO:100000000000,PARADO:000000010000,CAPTURA_INSTRUCAO:000000000010,BUSCA_INSTRUCAO:000000000001,EXECUTA_NOT:000000001000,ESCREVE_MEMORIA:001000000000,EXECUTA_ULA:000100000000,DESVIO:010000000000,LE_OPERANDO:000010000000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_estado_reg[9] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(D[4]),
        .Q(Q[7]),
        .R(reset_IBUF));
  (* \PinAttr:I0:HOLD_DETOUR  = "193" *) 
  LUT2 #(
    .INIT(4'h2)) 
    erro_OBUF_inst_i_1
       (.I0(\FSM_onehot_estado_reg_n_0_[11] ),
        .I1(reset_IBUF),
        .O(erro_OBUF));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \estado_OBUF[0]_inst_i_1 
       (.I0(Q[5]),
        .I1(Q[7]),
        .I2(\FSM_onehot_estado_reg_n_0_[11] ),
        .I3(Q[0]),
        .I4(Q[2]),
        .I5(\FSM_onehot_estado_reg_n_0_[5] ),
        .O(estado_OBUF[0]));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \estado_OBUF[1]_inst_i_1 
       (.I0(Q[3]),
        .I1(\FSM_onehot_estado_reg_n_0_[11] ),
        .I2(Q[7]),
        .I3(\FSM_onehot_estado_reg_n_0_[5] ),
        .I4(Q[1]),
        .I5(Q[6]),
        .O(estado_OBUF[1]));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \estado_OBUF[2]_inst_i_1 
       (.I0(Q[5]),
        .I1(Q[7]),
        .I2(Q[6]),
        .I3(Q[4]),
        .O(estado_OBUF[2]));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \estado_OBUF[3]_inst_i_1 
       (.I0(Q[2]),
        .I1(Q[8]),
        .I2(Q[3]),
        .I3(\FSM_onehot_estado_reg_n_0_[11] ),
        .O(estado_OBUF[3]));
  LUT3 #(
    .INIT(8'h54)) 
    parado_OBUF_inst_i_1
       (.I0(reset_IBUF),
        .I1(Q[3]),
        .I2(\FSM_onehot_estado_reg_n_0_[11] ),
        .O(parado_OBUF));
  LUT3 #(
    .INIT(8'hFE)) 
    \pc[7]_i_1 
       (.I0(\pc_reg[7] ),
        .I1(Q[4]),
        .I2(Q[0]),
        .O(E));
  LUT5 #(
    .INIT(32'h55555554)) 
    u_memoria_i_1
       (.I0(reset_IBUF),
        .I1(\FSM_onehot_estado_reg_n_0_[5] ),
        .I2(\FSM_onehot_estado_reg_n_0_[0] ),
        .I3(Q[7]),
        .I4(Q[5]),
        .O(ena));
  LUT2 #(
    .INIT(4'h2)) 
    u_memoria_i_2
       (.I0(Q[7]),
        .I1(reset_IBUF),
        .O(wea));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2024.2"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
FPXllyX2NFs/RMngGqZy2bLYbZr92CdofeZrJOHklWXExpaPgHNYp2Lzm4MnflbnrfSkCmLwwKT5
zfRgEip7FKQ5Zhb73p0MAIADixBZ/ZRt4hQkJL0T9brm0waLHfanjnov2aCX6jN3LbQc3ujmDga6
Dd73k78u4xjRTDv1/P4=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
kr7VKKvChFoiyRCReag+OvU3jnmG9pN0cv+BxhNmMKLthg/ksgNZyU3L+fQ7cmIQELtlUjwjkBAP
Jjq5RsCnHbJxj+Ys1GNhriiBsxLqxWCP8onhAVvgZN2xZFOih0UWpqlU8NVP8Eww1ohvkDgxTstC
3kDmYehxIUJjqCC/mgRZmuezqugrFdubYmBoz16tUvD17iA5qqCIMS9xSIXYp2LBNekmWEwrVqzu
R4koEo4UlXl/CEw0XY3QvMoHnlXgu6N/6sc+nxZtKSwjiMVvGnZE9UVvJPAC3Hn3zKFGlK53mmGO
Tj0dWzhwX0ahSYzkyJC/HLdbGZmriL2UNvDyFw==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
CaLc9FGt3AdRHfNtGAsGFY/QEvHY1Vv4TvvgCDsdDMqiuDeLizFJDJeskBWjeKDoE2cufK8TxiBq
mySRQNJoeOKnxTiDdf+Rx6m0iR6h/YeswegYwgghpM5KVrl6mSwF3+4yEovPM7a+9ArDQ5vl+WT8
SilNGzyW0KnTwe7+szs=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
cEnudSW1X71p0Xuq6jrXOxHnBku87IA0RA3zKqmeZHZM0r+9rEm5MSzX8RecnQ994yiqeyxbIH2l
fGEzUzr0ZzryS3fkf2LnJuB39f2YARW9eVCSiaeWaraZuY1l89T+h3vgdlurS/1LIraYLS1MyOXa
6F1LAcQp3W4OO4ctc3q1FRMZGldRS1biMsKwJ8Lxj8NEOm67UfgFrJNQAxbVXEfbWRWhKtwNxcTB
JbgC8j4EHkIA46mzoHloeBAL6KieplQUBjKXSSTb66rxglbFhWLy+mirROHcocu9J4ZbvTRYZEww
4lso1lqAllVLAoKYqa3WImZuSRoTbGDngBt9Lg==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
rOyI+x4PlmKcVSFoN3oKgSYpVlmYxc194Ej04il/YmBg10xopy4zmtu5sdCP/uGSNYcNGWeAiw01
mNf98KyNgTUFXruHCA38qjhhEIvl4vfWWn3W3mFRxrIuwmnreT6qTvgMaxIkCdVBDP7Iy7O6WmCf
3Va5X5hnCHhtXgX5UYniBHiLjmupv63B8XMAYDH2n6mQ3H0DF7mtb7psBafd0Z6+IWUbmzwMtKrf
ZrRJBGAhNT0i1KrEjEh/rWjN7Z7N32zQ+Pl1kc5gYCQIX5McfdTdqSaRVXZ/HF90ymS7/8d5LDyj
Er+ORdcjnOn6oAyY4PuUUl4OYUHv5k+RglTe5Q==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2023_11", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
bJa7kPSpDipzoJoQu1APEjc8vFLqBfQZK/grZvWijD7/FgMTerFCWLUY6n8DWeGdvjXvTeyrqCHE
2rP/H57wUqPC8tIJlGm6ZYQGjZ3TgYqLrJshDE5zYMTO//q0vuSraWvZP7A7SLuW6y7tFE/nplpx
L8gbYORx6j70okGUwnamCMS9yhFr7Z2QTJne1k4GNFGvy66URk3k5cBPl5j4/1yc4xGV+aWYl6L8
q8RorRU/CltObHKrji/jdiY1WtdGrkpRyCEFc+XNPazL9xSLLu5bz6XlvKwoks+8a5KYT/VFUovM
JbM0bpAXM8Z7rGaPuXjqXtZBg5praTZLu/WNcA==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
PYKBDinOGc/kIVdFzXrz2wA4/QNFxLDrQfTWfR5TjYE6bm49vrZi0bawcr9HXp4OP1+XxPLB3oCP
oV5e/rYeDln531ebt8yEg27XCoSHEX4FU8oG8aBJ8fqgWayOnAMJt025WodOxuZXbhT1zPo7J3uh
6iO9Mv7RtYE2fZ1W+G8oN//FTOEJYPWlKYnt0cDeZrN3I4rHHptZHuu7l8T+df0PYea3x6U3Mvkl
ojZ+TwQtdu0NuYY5j3QNgx3+W2XYq1M773FAnEz/deW54EjE+jf1jjrBk2pl8SYxeKuutS15oPVF
eHdqXYVcJxoUY5JH8z04lITKEnZ4oq6sYS6dog==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
tl+2vFCWZ583gQGsVC7oopz2NCKBiJ9uOHYBGzJZheOHJMqI/ehNvo25l710eBx00tztXzM30AH6
ZhAJg+kJwE2jO0MV5fmG5dnwXmLqoGEJMBs7xwWxvYK7w/0z9M0AJKD7HnuC+IiLhNU/fIxyuE+I
+vWqp//RcfY0tMMp2I2J1yEW6GUahS1ve/4JchssZ7Xu7VthoSDWXMQWATbvsUsDzeSo2+Ruz8Kq
Dc05HqEU8NgBxDPPEKLCcdKLp4byglwj7iCAtCjsPy8P18qjgb2sycFjNgmaiNMMB51WqeD+hneG
hLOue9bqVdEojkrb3q4WbsGZKz0bAGsryxslOlYHP1b8vey3yI2ixA80wyERe8d3GRIeZiSxGykH
qWxsE6x/iyi8QRb5mXZPMApA+Fln8tYmn7+1rFCm8gF4gJWhr1PsSJqTi658symGrzT0Ghjvf2QL
SvvoaeNdy0pOsWs7jLBFndd4GiFA+9K6Y33sziLToU9EvvFokENIslod

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
oYiCujFRj1F3wKsGZlHR9niEtR9MLXEVAVfy+f/3xrmpW6Ye5a+fBCvm4TH+iRQefGHNdMPnzTNW
K/pEPAS9uMJjOdFiu+APT+LYrSRnEg4W0dX5buSDGM6LBWAuMseoTMjbJJoYDGLRckJgW43E30mX
ej4823nkbfwc+Ecbrup825qLyv8RTQLNHafvJA5lSapdqXwnlOIYRmcHn+sfAh5pGv9kW9aokcdh
ObR2XYxX99rYloyvz3x0pmjxD5ILW4SQMB1IUEuuyqX6eb5IQ+kZ41hjvsHIuQH29vzpCfV9Jqha
WC5yxxK1R+cleZSKD1H1gVzbTei8uFs/91Bgeg==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
urNc+S8AFPj+GVFdqJE5V7P8O6QI6MA3nkwYb8NKbYbVufnXKg6voJIRYYeYr7EOa8mrqirozWbY
Lln9SLWnkaAy2LvL/N6WahoQdCt++4RH+xe768XvSrVUFPrIwZRixqMLurc/tPov4i5P/ukZKl18
ZPZvXRzUNlvCZnMPcF+5QCQihqPbjcZ0YyGgWgX/ipTGG3sNqmylGN7qLa4Rgqu/mB5a2xVyu5Wc
911+/X3VVFx697WVaP5V0SbOzYN8R8+8B8kdznwixMA+f4lSbBXyRysVOSzYjo8bKEMqyKMVBQn9
xDmEuV0DvVWXdO7VPvWA1LuJFwS07OxeI2GCcQ==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
QcP7fsLZxaDrG29e9HQeXfu2TsKsdyW7Yc1vWct6lbmDEfXkWMU1fFWSPIjPzRc9UOnfEu0bRn+B
D+8MWokqes3WF7txljBmgUPiNGZ8arUU6ENa/IY/Wv7iaB/ZKM5PtdnFAkjDIrYyKFCTz/U6Yzwi
hBGGarK/wYQOLzeeKRewiPTiNUL7tztWuMZ1t1msxD951EeKrwjrjcXIIuf/TzrOGUOlWgjHlnrl
4Q/lfMAnRLBNTSWG+5wWewCE8jK2X/gJ5AV4p3x1WP3+JglbxpP39l3pzedXqciZPbuz2XlFnRPV
KByaUaAShzJ56p8+0HjWebibqQdieGNPiPWW0Q==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 16416)
`pragma protect data_block
l/oMBoVZtdYMtZH/U87YRAeG7kdVI0jJ83fhxIQFpNChU8HRI8FsNwo1nvksiPk/WnrPMUUb8DaJ
z2MoJL02bZL851Y+EdVWhnQKXvkfEwVo2UfY+TyBjZxdZIFmTDdfq7euNjy+Bp0VQc4aoz2znMtU
VM4E1roVv5vdVD9zLg+9JobzSHMArfRENTlGsNv4LcW2lwRtmlQdkSze4UgZmN/wzlI/9BTtUKuL
yw6W1N6h12tIcNH2FnxGxW6ZSjd9dPGFUIWyiZ3wQ1nFs+KZ0MJ/vfk0Sh16aGHD8OpdDDvoE4s/
FyHgMWAnrKR2DyrCzHwpfFpM6zo380FpeALaRFbmKM1SUotNBWLikHg8gA8QsAhvkKSollJcgj+M
RzHalSf1hcOlYQUsdF9ym+nZhtGWPZOb/vi8RYGP0FfNrX4usmSL/EKTFnchzL797BPRb319RZDf
jNFoYqJHj/MSq7NW32Egkf3V0BCHFcgc4iZIitdMNKxpl03XI1Yte2REVDVZZ+XXRG6oyDWRpZcF
Ed8h7DqeeaKuotlGulrVKL3wsFGZRWbHpf9xhYlLsl8kSY4y7Kfv5oscYPgX1WSvp8oQuOH1TtKW
MHpXDOEI4Ajzf58bmFFkd81y/voZZ4HbVP0zkI6GjSKfWWB433p00Qbz2ypDuZriUz3cJIJMArRo
SA3a8p0kTc8YjZRFH5MRgmcMYEtRV3uooiY/X1VwHG52YibAaaRcP2v2G0ZwPYX0C0JUUCBttcPM
D3dyOczGfFYZnIzNcEV3BhWWwHN+rfUyUTxr3dJdMA3dq5OnCZC/UGdcC0vo2/xEebnBrTdC9CqM
NPHKUbz4q7bEz7me0c29qAqp7BDF0Ak6LmCQOAo0GyoffY38doQZtNo/wP7We84oCH+5bo6Lc89Y
zE9ryH8TRDBt1UiYevF8uKywfqBJyJd6L8PJbmktjufVr1RvaN0YWq+ogbkfU88ZQD6RfUYrOjfG
dv2L4UoBQZ+Zv6XE980xYmhG9Ol66W+4Pwlwx0/3ML5pgfQRbQiNKIWbbA/2GsvznHAcCNZuwjWl
SOjFmCMMph9hoM+srclm7nRfqMG5EwZDFAZ+lyCyXxBMps6AKLFyipBotckRWMYGosXeI4sS+iWV
gLPlZYeDSfercREA7KC3RR9Dby/ioh82G7I56i2hfmtbpbK8aqeXM+KnsMy+dgOXRALk342sa+iB
7zRc4B555j6ZOdaaEKYOui7VnFvIyJ4mE616YcA/TJirI9MCowNSiyyYcpo3TTTDDZAp0Zc5RrR2
U1reiCt9vQG01gxEimq+2Pk4zW3qu+IvcjPs+KlDYmsjNiPr7C0ytsB2996hS45VRmk2uYx5VQrF
YXzDlvxwlCqVTgOGntGemKovU821Q+hGWKLEc0od0wB0/2/cnb0puXMBZrKMVv/hhedbdGoZOFt0
6XBRg5gg+NmfFoKX9eKe0AGyq8Vm27aWc1XcllHgM1qXYrWVBKOzQ69JAj2mGW6f31KBdSG/pFcd
/ZSZfh9UTZo72unTDYPoRS9GG8y0Em5V1EcKWFFF9n5h+vnASDB+UEykDSn93F9/kJBfcUoT2Dx4
tLSKwQkkp75c6JY/OM1FbqoL+F6/hjo/KMnMJ0hlBAc0U+jHTEVMTRbYEFVCeQfYmTKtpGFIJ6dO
eDN5c38eYBtrfbWOvIEUOI/1IpDwxmapYEfTZM0sZ3mUfn/lAW6Z8ZbDlmXzfPPumfmG6iWrylJB
px4cvHzhQAwZc5rv8ifT/MV1o9Xgqy1utizND9857/oSY4H1zIZg0Ua/JtHxqxIab/iNOM1hIHDm
es9R0Uy1C9heLilEi2yLLq9TCX6uO1/BybRZjWaW4llHOl58soqT3OU4lBpistMT7mHEJci/wtem
Xg2eYr0kTykEZUHBB4FrcwaET3k64Kf0GBcJRzolFZsCKYmXujYWGxoUUr4ene3GRt5oiH+sWlzy
uhVX4DRRzlzqEVeF8nMAmvumWEtP7f3BNB0Hvg3tcxwF6b/XFUIdDbHU6wqSTLUBhMuZrjFrueBg
lhs0Y7rRW4RH1bIRtOWVfGEDPpcMzPEOGHVgst5tm3u36OYUAnYZoniKBbL61t7QXqftga2ufpsG
VzBl0iFT5j9uek3tAUVOvXDl47aA7C0eKqr/HlWrDq69Uxu84vfaV6YhrCwG59NO4AWM4GMolb1b
vWtaE09FSI7UeyWCc8AEMQRwsPIflqGzsx4buiKnzhxqf9EiVCkyDF23As/G2iDjcQtljNedffSD
irZbQZw33sk8moj0Macv2w3GiwQikdMlGxVnWOg1A4EAPzH6KqSst6d1mjWXZytsAivd/jEhAE5x
Odh5XRjMoQ4SMxW4ztQieOvO5ujPeCL/ll6dSWsjMCWWYryCNJqUCUEFSjp27n70kFCO1FGrbqiq
274L6D1skvaq/Cn3gm+vBd3gWBbrt8eZjCo4xiGWL21ibBZ/b56GzW2G7LlGi3bUX2ipqwv3DW5v
MGtz5+tis/JxIqDGaZ7BVIw8PgTMqAv6wYDHJUEXMFHE0u9cR0JsDxsx28yOpCZK+EH5u4zP/HMz
ccrOhgXTYQ+OLiM4MxNcFtOeHJHu3Xx1wh5e/9WfSSWU5KDvet/nL0/8gLPwf5G/HP0nHLSlEWjc
azreZeYLFthGWbr4s0+1OpIYMe5afGMjRW+1bgipOYHol/BzjgkvCF9lg4cvAXUYzElNBQwEllLn
Lzor3zm2QRTKR+RiUnxMJ77nX77r/7jTvEnIThffqxfSSxbGr4TPAKNRF4RxJOD3EUtm3gVRXcvM
OHd9AR3zG3Zk8kI9+fpiGFgJlpIPBzWMpwqFZOxfotTXVQqcquN7INgMW5tIopIirS8jp+4y7dvN
qGUYFarF56dlqdiPUFbpxEOVa08kWpStOM7pgRpx4q8q5zKGvVKjRhl7o398nS7owPHDY1su293I
UEUoSaxpz+iV1CTQVtgQRqYMOTWxb5mUxgSOBswGSfL1WMyUbKWpXO7oCuglGYx6604YF4CYCcvy
X98PP5W/PMU7frfWKrqrYHeg4PdVLw8hhRSQsk3vdf1UmW62WmN/F/QyzUkSmqw+4R4SgnGE9ctE
gZSPbMUUz7gQoZhmZ3AH8RTQ6QMzC9pM/OZEjA9k8IeygK5hPIudVjUzW4AzMxKttvePAPgv8Mc+
nO7NXoSNsUhHl6l7qP17JDP8R0eUWJVtxnZMXV8S3XBSpG1hq79gUNnCpOoBvrbq1FgedJxXuK2S
qlTIrQRwrX5ZGvMTZjzGn/YdE6b6myq9DoFX59T6LMXaJDWp+2Pp/QmLTeqeIm+R2wp7ICRz6eNk
AgvTzOdWvj1+SvWHkFo/GneIFEb9W0MS2UYrlqkXqoIwR+MmQPgu7FQ6t/9P+YJ/bFr9+n4rtbom
eQect2iHJ00wmyykacnXAqqOmVA6tYXbFoBHAVEHw2I8dnmMOioLufi49+X6zhAa11Hkp9c4MkJ+
PBoi0xXg4Ka9gJNtmFLlm07J+avEs0uRGqRSHucF5WmJ6FYhyi4xM7U38P95mKS7adn7JZF28u8v
cu0y21Aow2uELKemUx9yRy0KzJkNHf7e1zEqT4tb4NoVV5Zf2ytd09PlbmtKlHi9iUIpFv9Rtl6p
WNhkCcGWK4d8WCIHx01WFc8I1DMduhnuMVQeMakXQEFbmQwCr4lPjTLNiqAeV5e/iL8bqF9cNe3W
nLVlq5XyWKWrV67y9F0DzNBNqs7t1jJO09IjJ5Q7pizxB+l7cJepux7Xb5cBVLAsleAHvAf9ZWl5
PzjwP4kJ7oacI8tvHji/gB6klEoWSkYkE8zZcm432P9FfYHFvMZRP2Az7Wa/jl31+6ZUgd4NOrZ8
rAitQdk7xvlczXnM0Wyn5IljgrRUthDZ6hr03HDfAS9Aq1ddJHI6IbEKtGxf0RHvSg3jWTWDqpFi
d7tRxdWggBItC9FJI0KEW6uSdS59t7Dg+1IdvxgjGuocmZd7yXt+H4+lDS/QQ6pLmsK1HNT3xtSZ
DBIb1j5fUA43PtNTFI5YSiT+UqmVLEXldEgODCP4YJXZWW7cJB41AtxQrx6gs1hkGCGR4ePNUvzn
/Lkb6eCjBZm5uDtuICB/aCq22C64tsfpkx5TzhBEqaw+heLx/6DJRN4GzCIRNOIrkcGw2WbeytRp
ICbRTKfJDhKGJI/iZq6/UAzJi0hhAmgQ2OvrCXT5+3pdsoFUiJ8EHzbGwZ6uLpvmgYMnNCa2OlV7
2x1jS0IllZDYYWlouuVG93RqQ2qiZSlKJ1V9tPpq96uXIOcFkWszCGDHttehDtI+Z8oDQTLj+vpy
WO5B0nUX+YECdIiBtT9yzxH/leZ7lFFmGgKP/End6cbkECpmfZcJKPpkb9M9R2rkZARifvzvmhfs
VpHKjUzVo8wWmDCElYgE5U9RlJfmgTIwHgFt7i8M9cXHkMyQiYvG7EvP4EXR4OR1mK0uKdiGBl0Y
W03owliISasw3mjFPqeDq/wdo111dloxQSdhX1rtucKG4JRCWJm0JL3khZo/2wevmdVPycuV3e6Y
cL4QbbrmBiLXXAFEX8bxwWf+FVZiVrnbj/mqtLT/XHw8w2TQwz7Y/eZVampnpxL9XDJOEKADHEvQ
OFYHujFXtJ70sSAW8nGpYybcKLNQvS2aEQh+sL/piDIFbuBOtl5tLXFMsMYVlQk/43Qcui0bUAVf
4fwpbdx/O91FSVvc1XYgJJrkBx7tGoyBQIuDVZv4yNDNFmji5e7gsfT8cRGLT5ozWDjNTNGCnGlj
zaTjAWzqe7kS08T36cCLaTIy/lOWKfX75rDgUV0bX0W3WF1U7iJndKFAHIcqNH3N11KSYpQYj65B
OeEdwoC2twTC6lCV1VB2RSYkXAq+7rNJAaVWMYmzamRdgA73MvD4oowFERDtxjA22REZFr5lqxcX
/hWVF4KICp2bOApAt8tRani3zflDt6kqihk6v1FS7U0tbInuBZ4rHm9aVhjUcI9gr75/An/r5vSA
YY1a16LLd8BTmL21jvXDUkPv2rRNwmi6yuD7DfdglSriHZsDtRA9b1P68JPYXV/rauLyDaLaHzt/
XTztuxl92JrLFtLGEuK04oEMrF6g/hOaywNrxFdx3ctwjsHkyUZvvlPC4Zumm0AEEHz6rIbU82Od
TsCqmmOq+ociky+5X2H4eh0mR5+DKhOYpoXNhVZqjoUQco0elsXGoAcxEPD1LBwWAcmoOC6t+nJW
yD9yD/SLA7/snF2iePMJPq05VJ06nICZvG+ywqo0AOElnubxu2fuX8nTDf+8tayxV6PdB/ern/3X
wISx7JxP2Xqz6OgwGLZyeLObLs0VePwjRmwlrMcsYWJ16zsmv3/vAo7CsN1C/DFYacwXPMk94/gL
1K5RG7JrW0+yHJBQgHOVWFeWIw/ISaiFpZs9+mwaicutcHFX4jFQJOw4DRwzrL0dsxuX2bAK5PRT
lDjO3lwb2hkbb8k6+EC2Ukq4nGHyr++9K2SaK8TINDN5v9KbnJzxebvWcnV5FHhb7O0Ti4zX0+zE
1UjLFimiIUG99oxazGKPlHC/8hVXiUy0KNxFbarOYaugC7ikDiDQqc6upjcTb3CynGlc9CeYyQL+
ETaDBbElGNAQwvLhWsxfMBoz6ANELchFGyu4Bfun8/WzFsDP/4pgPnH3xilDtSWJImX9X8Bvct0I
J2A9lYJWpePpQTl3o6HFlPvn65bwBL62Z3h5xAphroltXKSYcSZ3L5PYjDkjO44Qak8cF9ETJt8M
MeuAQkT1W7LzAqIeY8gcQ7WDPvbFlIk24+9g6EvsjjNP1yaQSafy1sR7jkHpnnAXmqKLCA3kMnPJ
4QbfoRx9uymJfpEWjxdveqzWFncsBoXjwE7GycnVZIQOBUfqEOttspUToJGJ5zB4YTs3uByEp1Ff
pf39lKQon7zQatNpy3/G50k1f1J88y285W+YEIPxgqogCaNIvY6gw7RigmMNzT//SQANgY+pfBjI
l20jxOr6S6U4W67pd/BroAo2HgTBcrQdcF3hEjNsosshxhfkJRN8I2LUlDgAvn4cLHq7dtmfY1cQ
nusFQ+HKwqhNDzqDutGo7LKPOee6kpaRHds6xL7Ia3UPA9s2nB5SpkL8Qfmr/MPcrTkn3jtqzmvj
5pvsarTDhAFyo0eyXkUs7sQVjiVnWOCZWM6YdVfR6BlG69pPiqcXx6o8GpGDfFMMNf4kEmx43wax
Ro01cGXPGFCiA8p302Dfha9kaiXI7ttjAXN36STTAmmymtx8GBNdbqBsXZOdskZJT+d+5qTSTW1d
/yUfa908YWsO3fkAk2p8avHxb8MNSOmLbETMBzuqbFoIE18bZhY9reRhkEafafE7nCdqcFtdEQeJ
h3jBW6m9k+zoCXZ/s9w+vowLxnbzaCWoDo4BCNYCybrPGIWPl4cTlEeFJ5j+/G08iRs91OSS604z
skRbYaxZAZ2RkMoG9NXJws4YISSumPUlgxpHEnuwWdbguVZTCVA5r2n31N3Kw+pwok89MdRk3J7J
qggIGGnIenUIuvdkoc51i+yB9ODus4568kRRe7VcjBRVWIfHUG/DZJMirDUi8TsYoi56ZaRFpcOr
0YjTmPAWboDXdBAVWcjmnF3HMZ8ksM/llQeAHbi7q4VtTyWYxYyqLH6xsic00q8E42LOfuKkh6U1
h1B9bHiflmebFq/t/qJbNRGzlvGuNW1DNhGoVx8tEyIz2I0nRUhRrEnE1Dg/X5bWFDtwVTL6QP86
SeXPuX1FGCdOTXiTKHjbuHyPd2oROYf72RG9C8EmuovSIjrN5L+eqB4n3oBQS/CE4DnJDOlEBTjd
JnuQ3XJ/Ubf7ywSLcELsv+LYStzC6pboPvvLZMew66+F2iUIG/dV1Rj71c5ruKkOXjSjaYO5dW8k
uE/sG93oKFavA1/L4ih8ZacGg3m6Qathh2LpUOHD093U9IHwwe8M/EUO+LgCE/QtXHQY6cIUF/9S
sB2Cpk6aapTbAe38ihRaN0UDVaY25KYI51ibspL0jLG7a+k/0f4M0auPZEyzR07f9GlbJa9Owu8I
7UmpNyBbiRd3pfcU3/7M4AncTLl26TU33VWe8MZjhk2ad3OWw8GfAj/MEw+yM7fI/exUYb0NsvSX
SD+WZ4S5W5N9Wf8HSYLobayCFPgqlwjtIDeTt+7naPmz6mP+uqVEOgIOs1QZzf2ATts2UpVmrHZL
qMD1QlUnB1lduBxhKmFBelJ0mie5mjzc/FQ8RgZUVNZHCnRlAEf5VRPS3Wmsnpb9lwh/sCjyrvcW
qvYfCBIHnI1WDQKBrG09PqQMu/C+qpuq1TBMPsknjdDBT7XvV+nF+HrQl5cuxZzSGaEZ6i1YZU6r
91PbdXmZ+b33yttNEkt3qyNdMyzTCnoWTC+XbP6SZrqgG3+59H6FugZDZ8opekx8Z5PXlCpb0lyq
FQJDIeFTcGF4KI2rHGTxVh7HC13GBqM8Eel2VZ5eAzZ8eAELvRwHinp0F82rYONl+wxLzO4kwSz+
dLCbXGSgNmu+8hbXixq8AZjTq9chkf2xRXHeOOvc8JRSfOfbMVaZkmEQOkm2FJTL0LOZwsSNrxKk
A5swhIzd3Rynz9hOkvg4HEnSU+L96es3kxG8vHVSsLKfGSDJmbSErhAz0HsEm3N1P+qLb2LKFKJD
5AMViBwisuYOePZBZa7/G0nLD6+Z/dKW7s8WcSIhXuST1eaDHuxOG1OsNwO+V9CGIzJu/u3q7NzJ
TFjkhvncG4yItkBrdMSitmhXcf+Zl0UFRzJJZ9TOV0h9iRFOyeNtlIWRXcg9lDuPfIyi29Y32fo1
7M9LL/zZYnPsObkpEwumrz/Hkl56KCVH6pjamsmJ75MkFFp7pSAnD5fqALOeay0qsKagYXs7z+uC
NsebABiXr6RLOU0fdphtfcEjO2eE6rbYLdNbeLN+PmABc1gLujxmFeNWGWA/o9FCjp3IwS+E09kx
0w76FtV8sAacACSHPYp6H+cQW7H5H5oUAzqwoL2/lzBTsKivigvuYLixo6l2twqnlDPDF9YMf8VL
dPS4ek9EfI/s2mkJLi/wRaZM18hMdns++jOko3Wrbmy868X5QxXR4CmpJI/U9r3XpN/9OllXMeqf
4BtHBrybZmDm2OoLLHkkhmZ6ik15h4XWh54sVIpHo2ar09CWEkShS/oudDbAYjJctfzVfFMREw63
Kop14yyVPuHpteCCM0IR0OT66kf48nJaeNySmIOC70rZoK9fhK+5RMwoVCwa/oOC65klyCttfLLs
bJ1vkgGzfYRYkDTtGllPR8kF9q3gB/MmRtUDAbhDbusU+OcCI8fgyZVL4so3Jg46E1eb+1kNNF2B
Zfzb0KmVFTuwNC4yrNq7ViUkTQq1Hb9kcGLAd2KwT9cu6g0bK7QzypWSrSeVNL2a+mxVsl9B31jT
YVHC6Kc5W+LCzUmsSPxxYK7uTDCsGsMRdcFz0QPCyPM9+dysm0ToMPK9JURQD+IIsHe/JvPyKX/O
aZ234J56jSUPAUt6ftNPYIiQ0rHeBJbajahACpybHo52v7pItL56mGfgDSCj0dvn5sXAgugMRlcB
lwkY2lhn3L+A7x/xgNhw1IM8BpQZOy+Ebj0LXrZYFRPvZYfHAuWHkR/q32m+jp+CYpPkTKkBV22q
YySS0ja7JX4Wl7p089thuH6PE5Nf1C41YKj1YNuWk18D5eCJfq1MidYTszsT8qS9WS9pcK1tIogG
NrPNynjsX02+uNrNS4FUFqhAO2prjzXyJ+jtJVBcXX7VFhRrRWZzE/T0j3RCC2o74qCfCviDQuoT
iQSODU2veSjt/+p4VpJptR+8qVIuD7Bh5XqCLDAKWvb0IISjrj9X2+Ka4m6OK+UPoEjb6ASizkvF
SY4jhe213vhPTCFOGg0ynDadVlVNS5DQxg3R99peVxoEeJwM4mFhD48b4nqpHgkVY/1kPu+6LnRA
dsnOn5cSMVAic59v7mMG+o8w5nsGlIqMbAj5ZGg0BD89Z+23ZpsTWrfFHqQ3WBEMjKEXEjwItJsd
IECmkyrOhgV8YJ7Pdu6aDkXd+vAS+kcdCRSW1IdXWYlfBIYZdv4TjGRj09klroicB/IWEOrrcPKM
72OkJhIvF4evKshpkvnh58YT2mSc9EkzhnGOs6vA/VUeaczD87EQBwZpHQR5FA6VikGNhmhWaYUb
GYPtOk5uaf3joecX/Q3qPesG6yVTL1nIg2kVwB2bbQaPCWlG2bwvYIFVk4JQN1hXfRaDQ7TJfZ4t
DTndDb6EF7lSSQQYXLOYH23MXwTMNTzLJbUM1y123ld/TIKfYi8VB+PkL8ir81DK/LKKoGi1z4x1
szvwuJTl9s6P95Man4PZR0hX/QNqKkmox/cAmcKfWu0EmljH5YNcc4cZgHd5MY1/IDDQPJWrme/Y
1w+30RYVKljATeekr9G4dsLgpM3E1NXAJvb7qqyqewgb2sxcHvFMGNdcth83r/MAG9/GTZccUh1x
i4FV1xiNPmtnyMMj+v994XJ4FPV5lgWgDyXxU+A/vVwipm2LVKZy7WKfPImxcGwXtyGZy8pFZU2A
m0HhhrTZAvpXj0asJyZU1P6DDrIw8/3r5G7ikZ//u6g0X+kKGI/4ErBPkwHhMo9umgJnkYo2QcZE
srI2hwWQqyZZAEZqw1i5RP2V5LmMemDGVSH7Hq9/jKeEC5v8K7tpu9oFhAAnJh3sjqI7UMgia2yQ
OtaloNQKsyTVjyzTVBJRqkJaoRPZNKqzpuZal659Ao52+v1wa8jkAinMr+xEMpbQgmGwhACEMGOs
8HMEHzOBYIC7LkTwonPZ+hX8C4LzgRJwWWktO677C9IcJ1LRjbP9e8jnmoO7ROvGqhnb262m/sQ9
lnq+A0H86b4CMiF+F9vOUzID2NV6tWyv/msM7gHf9u7Jt2fbrJoA7iLGhxjFb2S55EJd8AoLt7HT
FyS/0EYzvyPmdZsdPXhnoepMkvmXKj3rHFKR1gvcT8x5MT6wnG8hSk3kV9lq3SOeSoot1IJ1LBGB
0KH/P4LuF0pNFRBuN1uPdeL4CFeexwz+qJMiO2ggpJvIYmeTQ48aRMZPtsMR8ePaoTudJmS4ivjq
8n4QpJmImsEKN5Tnq/ikgn0Q/WLASPI8XJchRTcoboHL8eSDzYQ93saKPgWmMJUJy2ltRBIyWgRn
WTk93BHB1+h9Q7ZYSLCPw4BfysMmDdG9Qg3ND3jA5nruCB2bbpBQq6qLIPd7lOCB8nL4Bp3Vy7Gv
5ZW6CBn7Vtd+8ibs01iCyIhqM/gEyQN4E2MMytFGbN5kI20Krplg/qXjjunv8h3+OxhGcRP3Vb84
BvIrN20/TOZdH5Oa5alXvL+b/uEqrXuKd1jXQXTaOm/ios5G+NxIH07YP0FWLPEyiRohOL6zmTYi
wJSBsDh1P/VOaTMf6wBbp+tkSyeMp8YVQqXB7wDk+bXJOz3YWcvttGI2Dvr53UfzSNPQmDs4slq/
fVAzjbeVron0TxT/iWL0W2w9/2L3H5EDRyFBJ6pUYDnCwd8XVs6OzOuNbF8s3oJzZMzTPXwgaZK7
EUycUoox5WQsgoe2wAP3eEFmGKcaMxV/3DelNdNmDlOOnzSLghMriEMorIMEz+RvmmFiGS3pxKgh
BT9mYaeoe4R2/OdwN1Xv5LqVv3SIhKmBgJhs5Q64xLgA9bM2hvcnsQhfHm5DtHgZsY2u3p3+6l+b
wAwfAIJVfDHzHRvbjjvm5EeIlp5gBjRgzCIY3bZGKmkNbBFhRyuGa1pKShmPNMIcMEFY2mIgj4Mi
WSjrN2zXp64OU3H9sbuEOhOBmgsKOGrTudLVMw0Ix17Qnmd9ZGp4gKneWvwOxoa2A4sV2jXYgADy
KDn6dQmEHBLoELRCPQf730hkefkeGKvqXR+v1smeDB9BF0rIkIFnN59rag0znzEAy8vHAhaS824x
toX7wJptwvV/xJwxrFgwoJT61688yPIdwv5dRIFxJ6lfzXK3vLq0dn7smAhI+3dAK+wvjSqL21wN
C2O8HBXYfsSWZu2bRzCI8x2aFmQ77HTVohCHk5dwW6DiqAmMZe82BTRXg+q2ki09MjJF0B1S5B19
Nop6ugcbBIeVjTBnwYdZUl26+18k67KQVIHIm+IXhvhCOWaI2QpucEgVIfaG8i0Rdzona7IqjwLo
jR4PSLNQWjNZf+QBHRkrF6jjA5F8vNcZ2VRBsOoX2Svs4gR6W17wtNfr46JbHwHskTk8jdmW608X
+N/FT8jg05eRpVKhxF22egwyko2mi/qmGKn5gga4K2iuWDJKAZwhvVK6jCFOynSbgV26Lwd0o/Zd
Klu1TtdoYIkznvRLJ7fSk0+9txmL5+ogqJg15a6OuoIHGZ7Ef7Stphjzw3LAS1AAOQCa03YxRHW6
MY1N9tEhl4qYYUKBYrPMI4Uf9P2WIHBLN+UXYjgjDdMi3HnDgR8zyHnG5BiWcEnYEc/9IsrC2vlC
M72Ot+3BxjjdN3Tj6sidboAIZTUPw96DtTaT7M0PPlQo/vnQlFwXLPYo9GT7v94+c4Y7M70x3aI0
PqHFnLH3PkqzGPsG6MONE2EcCVL7Rw5lOJ8ZoNsZL9qkX2zRfwRLOuaZpqhcGom78a5w3+ERx2Qe
j5PUeGNajCL5nB5c34j03z9GZCsEeQEBADlJcwvpQqbFtaOstw70s9wucojfvJkph4Ta+ZfRj9Qp
ahMsKrWuoDpqya9lXTHKVcxHb61bOSLS+jUFGGwMhsBtpyvPnSgoORF+Q6VMWzfnvXw19NXPSQOd
ocAuJEWN70wEYvxMNy4E+LhTEiMqorGkGFqFdulv+LIIF8PWbuO+1frkOfagGlECXrztayz1Gpqc
dK/8HxA/mTeelz+u+70Mx3tkgp0Zw1WzuxIK4UPqsrB+ZSlf5e0dtXdyeyGJ9OxXfftHsqtLl7qw
iQYZ+ydgaRK8DKq/+6WIegj/qxmE8Ji9v19bi/hMj6is6sHBvdvV+MDxiSFRI6hz7IPSuAnBJltW
Uh9HEXyrQDcu83f+RU9tkhIrndmlZIK5mjC8L3oZ6XV2TNWzqEgfeNUklu4OXxluJsos0g6uggZt
K8/t/dEuM20rV47c1aKe6TkZO0pCsto8xsJFiGNm3b0EOphFMnP/rV3wKXeNT0jl5z+VlIelfXDr
CsIUspUha2Wo+pzt0gOP8XmGG7eoa7NaMboSG55ugNJD0dYbtYOWWNlOwlgUqxMqd4BQuanzPXlI
Kgx02HoilIJ8LGbD0Unof1QdVg2jdy2yQMNIZ6a1bg/nVRzctDmS5jmTQPtBLV4wDsfuYICIX0nU
4ekq4mipd/qEiqUmSPuvql7TfNdhHn5Pg47HVe3brZKikhEAcqHd+nFXBtLw72eL+l88Tvds2rG8
iZ9WMrLXWofmMNGVlM54Gy3FQFIfbKafJ6c1/tqhswqcI4/6WDgabBKgtb8PrJG7YqJlPq1pLivN
YR4mnaTp8THTTYXTSsMzLtbROOhPvgSSRSfSCW6JaEPh3xiD9C/IE4iu9F57SNe9EhAkkSWBJvHZ
heUlkDAXZtjp4MSkbQCZgzTFviiyCgywDDZrhFKAeCmL/LGZb4wMNXzaT9K5eZqUOTiJzKDM+baJ
WR4iTRpwU7cilaiczsA4tXIrlW8IgStZArUugoi6NfHUEIMvMj6c8wkH/1VVJSZTOZeRHAvdztSb
mm+xTngPf1dGcGtc3SFe6XuZCftE2gKcMrAlE4VMI8T44qi7obkkQEd2FbZqtDOHOVpNCjVEDLR3
o2dVOlucn86RL33+YcHfzLcIJ6NekAdhTt0qciJGHR8pAtNVzY9pAp5Rji1AaCyBiZ4SfGn5awSt
Roog0BPLC+rAg0iAveN+l12fESy7RGePMeNJ4K3z5FVq1VVoX1nybTFNIkUdSieLj9Hue2wat2ZW
QwQYHqAiT1uGBd/LZFFofHQOiYdU9d7d/SkZX+lT2bs9lu7aL81q/3Ynr/9zfFVVbiqRNXuETQqy
xNDn6DNXUEzvDcYEzUbhaDqcnH+79seYY06sH8oAs9eySp18y8ByCz2vQibgax9GY/wZVfM4nVx5
bRIUP/sXpZozeiZQc4DDI4S+yyxT2G3dxXaLAi/GKMiKcN+4yq20FDvW2EcPv9b9QaZoRJJU6oT2
pKLaWpaxKgLRn10xOcBj6yGOz6iVuXXzx2DYxkQaAede4blvBig4mPTR+JeiCIxC4YL3a+1QXkat
X3Jot8wCq2YMk1CyyQfJmaovRyrCYHW2jF0HPUowmv6Ce9tHtJH8Bvw/+G33H8zIK6zMOjrQaPiv
xQsxd9bi8gIZwJVKEm+KQ1SLV6WAQ47DA4RX5v1eGdiM5R+xPk67GYi19LQuVUsQIKVgRMtD1BW6
vM205iQ4BVzuUM+klkNp59hKrY3YiffvQWglSjq0SFQnfothAXEl2PpYgHRVeHSW1I6gCKvxQUoW
KpaCI/ypbUkCbfpK3T+WtvRNC7oo5BBDPUnU6GtFOUcdDoLkJG0/hCF5l2c9lttmjVP65e2eVeTX
7psFxs2GHdv3hHZ7tqiHmqly9csmynAfuvSefDSk9hzhHGGYEhYJH14OrbY/Qe0RiGxY+JDm1GwJ
ih+CSzG+IVvMZVXyt/rky/A3RdQwBND3aEXZAwXMwPKYwBjhpw+Qi7RGA7YVimuACeODT+zyC2C0
zMhc5aAXWmFl0xN5AMMvJWCi7p+AHxgv5ropdCrLOuRQg4HWTnfSON9rhl4XRNpOMnMnay+GjBSh
VOBX7LBoBZCuUDAB2vJQeUI9Kz9s7SD147xLtqWZvtWG4JymKbUqeFbJDuqDrC2U5AVsvfdsbVCw
AOXLCG1IsxGcQdClSrW6dQB1cF6FILBuTAV56dlEiGsAHpDcsOKKGJ1IPPmkR8Pu8hakZQB2nxKN
cMadAevYr7jvzFzpVKyMiEmHILmFTJBqkF2PdBdLmJj1pjXg7xUzfE4r2TlTokf4hEcdChBpcks2
UX5SodEzGrCcqmQFwYdTgn1/b4zH3hM1nOqaNyrgOE7h0kXBC/OrmA/tQGRawoO8uqkipGYdoLfW
8LBgwdEOcD2iKT6I02Qn4iXpxsFvD8OTmm+diQZ/Iqz5qPk/nHFrHqBbFPnc47BAbSVNGzAKgOfo
d9EcFZdZOAjyPRiG8KMxkBFCINI72+MRfkNesROfBI4ir/GPtfbl/AEsyjue1CdLBKjZKjWrkItX
SE/0PEIMcftZ0WQD/RdssnTs5ISEfrUqHRVbSnRXZ1//83tsJj1MVvLR9eKPp74ynZHJQ6zzNIko
vq/ooCPHkNsYQ1JybPhZ87ys4KxJco/jtXwnn7pWtVm+4i4QcMM1fMKku1BV/QEryMQ4kPHtxuja
T2FXhqGnEl4H+AEy6wNU9RdaIY7QHV1pZMtHzuOz9er87VaGMW9nzGFaDtk1QhxXuj/zWC0Dt7Yu
UyfGTsTMRCOYQCENrGHXDj8HU04NLsdijDN+m+8+nnUj+SNg2W+piX7j4xp3B0MrDkotzqzqWKVr
zGKnC4woZk1YM0Y5XTBplVo1osnrs8cCFpXexrRZoykjL97/pDPCggxYVv3rf5E6PQBUcPHpxbvC
9Fq+MkLLrrQlfwYWYKvrBS1mPruBT+QMyZPDVgnOJOdNY15QVISEhXRwk/2/mwKnVEolBUU2HYcd
uGhbYuRErzy9XqFuUp065QVjSLtDOyTAygTZmPbaeEp0LJLhYjCLvHhmluh1bp2BIwPtJe5jin/c
h5Ki7s9BKguZiHLpQN4gKBpLgLwdHVsJZ99uhDQHPY8dQxp+sH35hE2RSvY87sgg2IHws6dSFlPQ
LBjqhyid7oWEim5yQSiiKZpCP4gND6rcXUcHTZtZbJR2+qY/5NToPwrlKBaHu09QwbqJJpoJW14e
dGBFwToYXmBsj4eq7NE/QWhNtgMS+gf49VvAPlAch8CKTwx/X5/nqPZuahNZD6dVJh++nbzHc8E1
BciwO1vBwLnHJr3oUeTsUAu69hHAc9J1eEtHD4Tde6LDw0vTWlCjLiozdaUAqfBkU9a12/KmSFOv
f1Zw10UtJEjynF3jQ29oVL8HZRgXAlO99WYSHkWaTyD4sg6E4vztib3iUYmhScjurfeDsJpXagkn
fmOV/f8TzzuQYNeiOskJj1XvR6oo+IiFwk7VCmq4nh6fHSAnU06W2lcru9BVVMYPHz2CxS+/4xDD
VNoYC2Dkr+CIRF1YsflfmmtnXzXdQMJBbzobFVAGaV7VXgpYxNhyOg/KHjnWULSza1/PB96voS4N
Chk0rzjw94+NVeo5SLZgQ91JrgXfCGJa7VjX5j2PkDtwHSuoXxj+dh5YjxbWOdYHTXLsFcc7VgdM
NzHpFusE4oh4snKpO3YroWWV9O49mj01C7kKXo0VBm0iwyTnADMlINKjRUXRx2uXepLD/K61OnOx
3NhN4kqx5nOFfaLePwvx2Z96Czh8GR2pAAlqn1lRg0lPzEl+FUYvAOJDp6hnpIikJy1vcRaS3bSs
K8u53omutEF0WAcM4mN4OqVJpPiNiQquJ/e9s3wSkLWXfbLchIlGUFZsJZPBKmc5xQb5xPWYFi5t
yCH7JVzqdPRgiUfNx0+S9Ozh1AF3PTaVGsjAhd4RUeWF6WR5wXji09jvGN6YEPNxZ3rUlDX1SUdY
xHQOk6c0Vwl4bmGitOW3eJ6n4n+BV96B2fL2ybUwkApw87K4+nWC4zoGVz8TP9i8aiiB9R9ndGPH
6qezRSCdLxthzsq6fxeVvPHDni1tspwNxu0kZOc0217N/vnG7tR3w1zPzDGyXsyPz/730yArppI4
HM4VFUEs6iU+BVV0uh+e1NC9msNH60QBKNVtcrGz4MtJletmNctYRBgfF5BsFn7z8UjCiV9HgtdD
MgHuCnupiHrmeyalgAwno27Cqfe0Yw+YHjS03ZMUWD1dXzSMR5gndv0bybGD96WU2bMHCrmEMqO+
8/a8R+55JSwXWaopF0r/6SKkonRvSxOY2BdSk/6xtzoVAnC9nFis1AsZ0N+yag/k56W/u5WEFDqU
xbxQpAdQqZWq11uYzEe78pWw92IgtOO9Mga7eWECWYGJGmc7sPRXrLnHtU4aoOJtlv4wS8v9VyrI
GSMOF5Cgp40p6hBKFrTtQupvQg4UEEFlPNiz1NvHLiiKRvbpXzx+sWks9TMMEpH31+G5+IWDZ1Cs
Dw+L7OGx9jq2idi3TuMpic/AX6OSnao2EUt1JnoZkZyzrv07zzp/oWMcVkLCXKv9GwGK+B0OyXWW
1Q4ALrNpn2oq9pS+lKmkNnwXPWGLhRvn7aSyA6ANlxeFWDYVQev0s3V2QtcyYs6B0uUlvv0tXaAw
TahANOHkcME6gIlMvh77maHk/fiCKByk90Vieca576kXe4GrfjhOMT0jS16h8zbJ5RuUZyiQb9Ur
3Z4SdzvJlz04D8nEfBLDyfOEbwoqz2ww9aFnW98qJcexd4x8FSnZNBqQWjLXg2+n35RJL+QsFeKS
gxVVvvY9Fs/Z/HjYFo8qNV9Hd/s6ZjbX+Cd1yji4/z1t9TYhazKy5KLbmmhFz1hW9nDGypvUZ2J4
hWaJqNCa5jN19dP7Owzv5H1FDLmI9SM8cBn9OJPC+ajmEgqWrCgLtkFOnKSbIy3YC11Me9OUaKOA
mrONpAHS6BVwj4i8cmOarFx90gU+RAM3ncWgvS7NMRsy2NW+bD6Rua6+pECr8JDPaBCPHWVansXe
vm0ScmHXVE8vOnCSJAvFVPh/oc3CqxAAPvuZgsBXQ/O2nI9CCo9r0lJhGhPKeZZq+Ii4Ajoy8ySc
QtxmCePoyqn5wvjUsyIhHrvFtc+SLWqXgjW184xaWDKmWfHeeMVVrgpswlbs3H3PijJ64U1AOOl+
IF1mpJGCNlBk4Wg7deFH23N7iniHk+WOfaF/9J9drml9Wes6OfStM6jMrXs1OEfrW4HjETlBOymn
Ea9ehRQkutAeCLo/bOVngHY59JURUE8ObikYUz+cClefas2+rZpXTxk50vgy1/IC34HZqS9oKOJ7
ySEVPovh2QHQjnHqKV4k1/RIspc5Uq++AsD0LmVhLm/tloIw5pGZW09V1Flyg3Jkgr0aYLCE5lXk
g8c/oWkygCN5liLxVIVzdpGRUvhF5cROAc6iJqKvo27b/YdxDv0qEkKUZp5MpzzqezAjkYhtaoH2
9+zVyf3VZ7DlDyfVSzT6NVAHS5M0PdhwSlNxEkgEMRxuMqeaVHDw1vYQKLnPlq7JrPeHBtoWJ4xQ
8Ylpu05sFin4uN/Lacogz+SETsuQ2A7/AFm/oOMh5t/cwaVh16bxhvGxdiuAPpoyf0SJ8dbXc+MC
Ee876aUkv92kEs1j3D5ZXSjDbTyr1EaiiMM6XvtL4uYNj9slJPKqdaxXKRIwq9/3u1iaz90PU0kk
ZhIZWDuc3Yfxp5GdSWaOeYFzD8B0qnYaNTNo5psTu0it+1DLq6jDd2qQxs1+3aavNq0SLRVq5WqV
OjVAdhqkaNnSDBfZhS7MjQkKcrI5xHqjAMEUoc5d82sOdcNkFAvtJWLbbVI9D8jZNYS0HtjSZSQE
VGPV3y/AmApYODpp7G/xd8T4aSd8CetmQMbp+1Q49HvAIcmJ0gR32rZk8bRKNy4IB4QCV08tSU7F
3dKFlVgNznilNpOODCCNv4zLsqyiZlKyUaN0tyiR+Inu6Frhg+5uW4w78a/bL/f0aqXIBLg5xnly
xnvNSTJpWrpyUrO75VIEF2Ok/aBc5Zvoho8g4uaMOogsnRlLoRyG7JtArS+0Pr/Qo+NU2cqbs5mM
KN1oWf5c+2Jy5tfFJfXu98/LdX/PpuSAuuhb3cqD6ls1FUZqStUoSnv1Q3m0wsV7RaRe2j6B2lEU
Ry9tiZrkjddVNOS5rU8+35qMHZyDChdpoR4FfvulSiG4LCZXWO609/qOYfn9MxJuPlOM7CYeb4xs
e24E7Op//eMnzy3mabSYY+MKRWIbj/AgiMsRQUfCz/muHdtJ6AviPeWfbVr/P4gomAqoHmjXYiW6
lYxk0me+bIa3aHIatMTFiXIGRe/h514ufmyQAHx86uDFBXf/cNXK0P5IWT+J2CWShg9XALvD+3pT
OGGWMwUgpONBbBVL847Y5k4Eeu5AKm8fhcZqVPlXIEM5x60QuJcNXTwBch7P65cy/Qq77kCExopC
X88F6dd3FzLhUxAJ5G+yTCY67IX6F551PcFgeH9CfcneBsVP06iQDJ+eMQ6wAkQk6JIhs1ebeCxR
NhnUFboRGIHIU9ZDNk1iGcWexTAIVJ3R5q9Cw/D8R+SdSNG1oq+LbUpanOzkC94XYIqu4n8fozZK
VWGYOYWFaEOq4gjZcBjE8n3M96ELc36bQAeQRxIBo+9rgNrljDBW+3cAdJhAvMuU7NjyBDy+ySUI
x/F5ImjWItZbSJpZDQSlVeOVOQ5J773WSTuLe/z/jzhXZbx4p+CEyToqWBzYxBUf/9BTZSoV3Os5
hWQLdcMW+8RJqM0etI3ZnRwgRlDi1uVA1SSxhibdWk8YcdU58meGIXfMUlWrBZ6WoqKikTfi7SrL
5QDjmNsyNcJp2BNqQX3UL922p/xHkhUFuxzfL6Kic3RKeP/mk29ntHLuiAbpM59wuhlBVQRAc4cW
ZIEEk66ScoZKhHl4tL81MoN1gGiYYxjA1LQaC0wxq1ohWrl5dJ/+AvbhIHTu3nGHJA/6OwZAN1kp
dKUPe+iSfj2hfXnNNY9LsHz3BHXy4qSiQFQdybBidi+fKAAWakHTnUSZ1Xm77TtmljQX1A0i8Ayj
SPcGwBNT84KkELoGyL20/T/AzyCBMqvvZbH1W+e83NVgg1wGa/SKXdvteXf3MvB274MpsuC0mCn6
W4ndyfpKgXS2qcqQ6EHrR/Shi5mcKD+jORKArl2hKjziWjSreA7ZGzrTzXLKahH/AcPX4Oo5Du8j
CSS9t64eBTl2ASUalC9DbIGIneySs4zjpPgmH8JyHEVSrM524fDQ7fJ8tl0OI5M5WZpxeltTyepi
0cORqCc+16qJwUnF3IVU0c+AX855Auz9l3/j3SYTnCctOlUsy5RRfS4jFsAzwLYhhbvIkO7glpLJ
rpEMqw6AbRDqI4duV1WmzDXIOwhmXcWXJOk84URQpu93Q5vLLLpGR5JY6NlgB53tX+TV4qt/UoPl
trnHPMzwWACFHtLMVkkioZIjBaasq/DbeGhWLvIl0ldhxhhzxmU3qnBHsRKaXBAj6Pv03Fhm3tZa
05z1LjCkpws2g5a7TS6YABMs2yVUdSYzgDvtaHtrM95s3/VYrB7hQcfGYJM4aNg11ddtwQx5B4yT
7OMFKGFIsrxHxo3R75gMHo7X0IWuyJTJ1Di9nBrhAscGrR+lzDYWzQmFAYfBXZE1FNAIrgb+2xR9
OpLWmxfY+1Ep45E2F5JJgKBkxmi00oJdfin7j3mb7sxllsgKxCCVsQV2PASc7Ay2eS9NEViEspYL
pSWKsLZ52k4qiIqZnpgIgw4mOnxmpKo5zt5r6Bc8jnOUrSmfkkOB6YugP3liVKN3vqQUE5VfQtQd
fI4C8utdhfzjqNM5EboRxXg9Wd1pmdef+IldWVPsHDycUoccQb/XMG5W1mgXCKsBQWB9FBDAm05t
fZsbHt8P5D9EITTDi3guL62CO/srForxwK4puOzo8f5USHIE/BV6c1rFYbQwSP9k3/rwVCOrrg8O
JVo9r2kVa3qyC7z/PdKP3Wuj6ez3VX30McTflVaMCth2ljj3fUmR6hVEp8m20XBuIXN//APqCw9Z
Ipa8rPe4ZH1HFc4l8DEx3XQPeFfmUBjXYg0h+zG7w20fx9Mk7KWCSGX3Irqh17UG6xCmOgkKF9vz
q8u3ex/G9/EUi/n2b6ukQi8oTq4Dr9tqE6S8FG7roUo4uyuDqJrbsJOYqw+D9vx8DdZbYOVDeqYa
rMtfoWhXbqD3pTGUNissZXWagznJzvQadFiqAM8cwVC5mQ8IWdO2DIdVkzu/8UxKZMjaaUNbKRML
a4CoWC4unMtNcvrTVVMdfdDxbaATUABlZ2NZLhj5/NRAc3KMtcOyx0UKffCPMsCnxFw3df7vN2zQ
n48XuL7ZRq9sr58jSD/n5eBy4HF4L/8DrwgTLmI9/hvudVwXfathz9mqZjcZt0014DmyoGsdglto
beWcFrho9G4W9NrCfRxDLTrZo2LOsxXLTQD+fg5yu5Sj43oVhrtW+Jn8UXkMzJxThizsY1eDwWaV
hy9/Qquk8ZUtTkjPHR5e2FYuUtppPSBoYPbBNrFxyt9VHhUbP8Ib4dwD/F9a70L7qncxYXq+OjHY
KVJKXkx2C3VKbvfXxU2YdtLq1lktbJcd9XaPbdXUSqNSzbOPryx13Low4uyDFpN2jzA0bn2HapzD
DfafODYIS9NaHTa3vahyQzjGdZnbKu/Dem51LbNHC9CYGKKu5uqjIngdbtAMtSvOTXj2YuiAS1CN
+s0zKGmZ1Xf4NqpFS/7DQ/ho/TxI6J1p7DaS6TwgVfXKjUmOtbXZXxMbZhj4/307tjHSEUq0BTue
WY4sQwu7O9MlEzuuLuydHT2AmnOxO2StMvdQHtMzEodlQe0exTd4vqeICCFi9WsSRmVruDPIJPlG
Vjcuj0TBdxBAbKfCF0jIz4aaD6WxdHxKBMa/2Ld8ZJRMGjcr4UbKJI4LQWUimsI3oHsg0y1oqS1r
fIpaoz6d28NNSkiTRW65j3lqgwmWsTutfVrkciXprSHVYLjyK34ET/iVXCPieGIs9QZdxwOfGw4Z
ptSnqUb4FEjbCRMnnZfjizaqcfoEnhFpTkFl/Q21tbKyFywy08kryqIkojxG/ObjTU5m+3UMHHk7
tla2JNuRIGy2LS3bGloKKY12HhodtEJHxwmQ5LUCa5dNUtSZK83fR/VOpvx4m5YCj0gTouQtuf1q
8or4igLUgovMlFwEDL+wF0jFfGtMm0JmC73uNl6ykuQ3/ZYJxZrwCfMfSe0VM1BEpKfs+8cnLCkX
YVMbluAujd5zzT4FeyhxTnxtdnQtjiGNidA0SRVZtGw9dhFQluv9xJffrdEq8zP12FvOpGFcl2Uv
m9v0/JsqZX8EmRs7ukvvn64LytHzerEk0ALHGEPX3adIvMbD99oHHhNNlFJYm9IyOFtuOW6fl9nK
lp3z+uJCYq2reeYM6+P/UuFxjMQpriWvEkq0M0Kl+5+UQDeJeXjQmpBKXvHLw6KDIf3S/aKdgDuf
UfVNEyDK3UAv/gbJjvmoP9ic3Z+TMcjXprQnwQBBm8JzAiXTaa0F9qYUirWDpg6/4AR1Jwt8ja9O
l2upUvhhAIKtAGLl9/LcR30Dd+WOCVXbZq8oLRxwvGT+U4Mn3elSiPtf0lHITSRuOabECBNFDUKl
8SAYgXCrLNOPHgY8aCq9hd7jFi7KGqTQchPYBJ8aavlJWMO5DXP/TkG5aGcBGSZSk36ofMmWg8QE
SnWdNJQScnPykUF0uxCpyP4/WXz5HjiQgU+H/99FzMVQAKm1/yYqIwxXzXYotQU8nEFk6ZQc/epx
nxxKk65mKoGwcli+O/2kLYEHTVy86CIy/AgUanqnTKNNc5eaua46dKOtHFQfWY4xj38A6/KKj7ce
1fmhxAHctOMmDDEfPRgx8zWIQ8XjNSwLCUsBykYcbUBN0i0hCd9NxJIWGkcw8nBCIJDFoLCF3OYZ
HLHYGQADs3uc4q5EEtglefp7swYonu2916n+hl4gw/o9J+wCiAu4D2SkssbzfYHh8/v6HukBo50C
n8cxvzWRnF78Iayn30JoreT1QY95C07QHD7MKQ34wlkVXPGr5ZxJUK0rjEFiIyyRh3TU7jt/BbET
WqGojQgv33TM7MBNLLf4NmFnBx9zbWkBgQKzvPTv8tThcYHfJrGc+bDtfek0FKzXhAdXFZR3/6uz
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
